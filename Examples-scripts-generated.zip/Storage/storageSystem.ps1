﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


write-host -foreground CYAN "----- Creating Storage System PHA-7440-01 "
$sts                                       = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
if ($sts -eq $Null)
{
    $userName                              =  "3paradm" 
    $password                              =  "***REDACTED***" 
    if ($password)
    {
        $securePassword                    = $password | ConvertTo-SecureString -AsPlainText -Force
    } # 
    else
    {
        $securePassword                    = Read-Host "STORAGE SYSTEM: enter password for user 3paradm" -AsSecureString 
    }
    $cred                                  = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


    new-OVStorageSystem  -HostName "PHA-7440-01" -Family ""  -Credential $cred `
             | wait-OVTaskComplete


} # 
else
{
    write-host -foreground YELLOW PHA-7440-01 does not exist.
}


Disconnect-OVMgmt
