﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


write-host -foreground CYAN "----- Creating Storage Volume Template shared-vol-template-dung "
$svt                                       = get-OVStorageVolumeTemplate | where name -eq  'shared-vol-template-dung' 
if ($svt -eq $Null)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ($stp -ne $Null)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolumeTemplate  -Name "shared-vol-template-dung"  -Description "test"   -Capacity 1  -StoragePool $stp  -SnapshotStoragePool $sstp  -LockSnapshotStoragePool  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    } # if ($stp -ne $Null)
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # if $svt -eq $Null
else
{
    write-host -foreground YELLOW "volume template shared-vol-template-dung already exists. skip creating volume template" 
}
Disconnect-OVMgmt
