﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


write-host -foreground CYAN "----- Creating Storage Volume boot-esxi "
$vol                                       = get-OVStorageVolume | where name -eq  'boot-esxi' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "boot-esxi"   -Capacity 5  -StoragePool $stp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume boot-esxi already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume boot-esxi (87) "
$vol                                       = get-OVStorageVolume | where name -eq  'boot-esxi (87)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "boot-esxi (87)"   -Capacity 5  -StoragePool $stp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume boot-esxi (87) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume boot-esxi (189) "
$vol                                       = get-OVStorageVolume | where name -eq  'boot-esxi (189)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "boot-esxi (189)"   -Capacity 5  -StoragePool $stp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume boot-esxi (189) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume boot-esxi (2829) "
$vol                                       = get-OVStorageVolume | where name -eq  'boot-esxi (2829)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "boot-esxi (2829)"   -Capacity 5  -StoragePool $stp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume boot-esxi (2829) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume boot-esxi (3649) "
$vol                                       = get-OVStorageVolume | where name -eq  'boot-esxi (3649)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "boot-esxi (3649)"   -Capacity 5  -StoragePool $stp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume boot-esxi (3649) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume boot-esxi (4058) "
$vol                                       = get-OVStorageVolume | where name -eq  'boot-esxi (4058)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "boot-esxi (4058)"   -Capacity 5  -StoragePool $stp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume boot-esxi (4058) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume boot-esxi (4309) "
$vol                                       = get-OVStorageVolume | where name -eq  'boot-esxi (4309)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "boot-esxi (4309)"   -Capacity 5  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume boot-esxi (4309) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume boot-esxi (8655) "
$vol                                       = get-OVStorageVolume | where name -eq  'boot-esxi (8655)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "boot-esxi (8655)"   -Capacity 5  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume boot-esxi (8655) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume boot-esxi (9840) "
$vol                                       = get-OVStorageVolume | where name -eq  'boot-esxi (9840)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "boot-esxi (9840)"   -Capacity 5  -StoragePool $stp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume boot-esxi (9840) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume Boot-GPU "
$vol                                       = get-OVStorageVolume | where name -eq  'Boot-GPU' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "Boot-GPU"   -Capacity 1200  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume Boot-GPU already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume Boot-GPU (5181) "
$vol                                       = get-OVStorageVolume | where name -eq  'Boot-GPU (5181)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "Boot-GPU (5181)"   -Capacity 1200  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume Boot-GPU (5181) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume Boot-Win2K16 "
$vol                                       = get-OVStorageVolume | where name -eq  'Boot-Win2K16' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "Boot-Win2K16"  -Description "Hyper-v"   -Capacity 50  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume Boot-Win2K16 already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume Boot-Win2K16 (71) "
$vol                                       = get-OVStorageVolume | where name -eq  'Boot-Win2K16 (71)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "Boot-Win2K16 (71)"  -Description "Hyper-v"   -Capacity 50  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume Boot-Win2K16 (71) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume Boot-Win2K16 (6331) "
$vol                                       = get-OVStorageVolume | where name -eq  'Boot-Win2K16 (6331)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "Boot-Win2K16 (6331)"  -Description "Hyper-v"   -Capacity 50  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume Boot-Win2K16 (6331) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR-' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR-"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (638) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (638)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (638)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (638) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (3164) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (3164)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (3164)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (3164) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (3334) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (3334)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (3334)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (3334) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (3765) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (3765)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (3765)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (3765) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (4848) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (4848)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (4848)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (4848) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (5538) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (5538)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (5538)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (5538) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (5651) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (5651)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (5651)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (5651) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (5779) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (5779)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (5779)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (5779) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (5933) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (5933)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (5933)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (5933) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (6055) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (6055)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (6055)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (6055) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (6430) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (6430)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (6430)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (6430) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (6921) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (6921)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (6921)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (6921) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (7328) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (7328)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (7328)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (7328) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (7539) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (7539)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (7539)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (7539) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (7805) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (7805)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (7805)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (7805) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (8009) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (8009)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (8009)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (8009) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume EPIC-MapR- (8990) "
$vol                                       = get-OVStorageVolume | where name -eq  'EPIC-MapR- (8990)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "EPIC-MapR- (8990)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume EPIC-MapR- (8990) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume ESX-Boot-HPECP "
$vol                                       = get-OVStorageVolume | where name -eq  'ESX-Boot-HPECP' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "ESX-Boot-HPECP"   -Capacity 1200  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume ESX-Boot-HPECP already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume ESX-Boot-HPECP (6) "
$vol                                       = get-OVStorageVolume | where name -eq  'ESX-Boot-HPECP (6)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "ESX-Boot-HPECP (6)"   -Capacity 1200  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume ESX-Boot-HPECP (6) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume ESX-Boot-HPECP (651) "
$vol                                       = get-OVStorageVolume | where name -eq  'ESX-Boot-HPECP (651)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "ESX-Boot-HPECP (651)"   -Capacity 1200  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume ESX-Boot-HPECP (651) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume ESX-Boot-HPECP (4908) "
$vol                                       = get-OVStorageVolume | where name -eq  'ESX-Boot-HPECP (4908)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "ESX-Boot-HPECP (4908)"   -Capacity 1200  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume ESX-Boot-HPECP (4908) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume ESX-Boot-HPECP (5240) "
$vol                                       = get-OVStorageVolume | where name -eq  'ESX-Boot-HPECP (5240)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "ESX-Boot-HPECP (5240)"   -Capacity 1200  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume ESX-Boot-HPECP (5240) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume ESX-Boot-HPECP (6154) "
$vol                                       = get-OVStorageVolume | where name -eq  'ESX-Boot-HPECP (6154)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "ESX-Boot-HPECP (6154)"   -Capacity 1200  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume ESX-Boot-HPECP (6154) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume ESX-Boot-HPECP (6410) "
$vol                                       = get-OVStorageVolume | where name -eq  'ESX-Boot-HPECP (6410)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "ESX-Boot-HPECP (6410)"   -Capacity 1200  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume ESX-Boot-HPECP (6410) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume ESX-Boot-HPECP (6485) "
$vol                                       = get-OVStorageVolume | where name -eq  'ESX-Boot-HPECP (6485)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "ESX-Boot-HPECP (6485)"   -Capacity 1200  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume ESX-Boot-HPECP (6485) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume ESX-Boot-HPECP (7099) "
$vol                                       = get-OVStorageVolume | where name -eq  'ESX-Boot-HPECP (7099)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "ESX-Boot-HPECP (7099)"   -Capacity 1200  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume ESX-Boot-HPECP (7099) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume ESX-Boot-HPECP (8688) "
$vol                                       = get-OVStorageVolume | where name -eq  'ESX-Boot-HPECP (8688)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "ESX-Boot-HPECP (8688)"   -Capacity 1200  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume ESX-Boot-HPECP (8688) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume ESX-Boot-HPECP (9147) "
$vol                                       = get-OVStorageVolume | where name -eq  'ESX-Boot-HPECP (9147)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "ESX-Boot-HPECP (9147)"   -Capacity 1200  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume ESX-Boot-HPECP (9147) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume ESX-Boot-HPECP (9458) "
$vol                                       = get-OVStorageVolume | where name -eq  'ESX-Boot-HPECP (9458)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "ESX-Boot-HPECP (9458)"   -Capacity 1200  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume ESX-Boot-HPECP (9458) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume HYPERV-Quorum "
$vol                                       = get-OVStorageVolume | where name -eq  'HYPERV-Quorum' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "HYPERV-Quorum"   -Capacity 1  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  -Shared  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume HYPERV-Quorum already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume HYPERV-Shared "
$vol                                       = get-OVStorageVolume | where name -eq  'HYPERV-Shared' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "HYPERV-Shared"  -Description "Hyper-v"   -Capacity 500  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  -Shared  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume HYPERV-Shared already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume ISP "
$vol                                       = get-OVStorageVolume | where name -eq  'ISP' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "ISP"   -Capacity 100  -StoragePool $stp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume ISP already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume MapR (4298) "
$vol                                       = get-OVStorageVolume | where name -eq  'MapR (4298)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "MapR (4298)"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume MapR (4298) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume MapR GPU "
$vol                                       = get-OVStorageVolume | where name -eq  'MapR GPU' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "MapR GPU"   -Capacity 400  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume MapR GPU already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NCS-BFS-Cluster1 "
$vol                                       = get-OVStorageVolume | where name -eq  'NCS-BFS-Cluster1' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NCS-BFS-Cluster1"   -Capacity 2000  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  -Shared  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NCS-BFS-Cluster1 already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NCS-BFS-Cluster2 "
$vol                                       = get-OVStorageVolume | where name -eq  'NCS-BFS-Cluster2' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NCS-BFS-Cluster2"   -Capacity 2000  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  -Shared  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NCS-BFS-Cluster2 already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NCS-BFS-Cluster3 "
$vol                                       = get-OVStorageVolume | where name -eq  'NCS-BFS-Cluster3' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NCS-BFS-Cluster3"   -Capacity 6000  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NCS-BFS-Cluster3 already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NCSHITS-Cluster3 "
$vol                                       = get-OVStorageVolume | where name -eq  'NCSHITS-Cluster3' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NCSHITS-Cluster3"   -Capacity 6000  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NCSHITS-Cluster3 already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NCSHITS-Cluster3 (53) "
$vol                                       = get-OVStorageVolume | where name -eq  'NCSHITS-Cluster3 (53)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NCSHITS-Cluster3 (53)"   -Capacity 6000  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NCSHITS-Cluster3 (53) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NCSHITS-Cluster3 (1117) "
$vol                                       = get-OVStorageVolume | where name -eq  'NCSHITS-Cluster3 (1117)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NCSHITS-Cluster3 (1117)"   -Capacity 6000  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NCSHITS-Cluster3 (1117) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NCSHITS-Cluster3 (3315) "
$vol                                       = get-OVStorageVolume | where name -eq  'NCSHITS-Cluster3 (3315)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NCSHITS-Cluster3 (3315)"   -Capacity 6000  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NCSHITS-Cluster3 (3315) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NHITS-Cluster-OS1 "
$vol                                       = get-OVStorageVolume | where name -eq  'NHITS-Cluster-OS1' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NHITS-Cluster-OS1"   -Capacity 800  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NHITS-Cluster-OS1 already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NHITS-ESXI-Boot "
$vol                                       = get-OVStorageVolume | where name -eq  'NHITS-ESXI-Boot' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NHITS-ESXI-Boot"   -Capacity 5  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NHITS-ESXI-Boot already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NHITS-ESXI-Boot (2) "
$vol                                       = get-OVStorageVolume | where name -eq  'NHITS-ESXI-Boot (2)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NHITS-ESXI-Boot (2)"   -Capacity 5  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NHITS-ESXI-Boot (2) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NHITS-ESXI-Boot (476) "
$vol                                       = get-OVStorageVolume | where name -eq  'NHITS-ESXI-Boot (476)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NHITS-ESXI-Boot (476)"   -Capacity 5  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NHITS-ESXI-Boot (476) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NHITS-ESXI-Boot (2121) "
$vol                                       = get-OVStorageVolume | where name -eq  'NHITS-ESXI-Boot (2121)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NHITS-ESXI-Boot (2121)"   -Capacity 5  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NHITS-ESXI-Boot (2121) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NHITS-ESXI-Boot (2315) "
$vol                                       = get-OVStorageVolume | where name -eq  'NHITS-ESXI-Boot (2315)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NHITS-ESXI-Boot (2315)"   -Capacity 5  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NHITS-ESXI-Boot (2315) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NHITS-ESXI-Boot (5518) "
$vol                                       = get-OVStorageVolume | where name -eq  'NHITS-ESXI-Boot (5518)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NHITS-ESXI-Boot (5518)"   -Capacity 5  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NHITS-ESXI-Boot (5518) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NHITS-ESXI-Boot (5672) "
$vol                                       = get-OVStorageVolume | where name -eq  'NHITS-ESXI-Boot (5672)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NHITS-ESXI-Boot (5672)"   -Capacity 5  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NHITS-ESXI-Boot (5672) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NHITS-ESXI-Boot (6629) "
$vol                                       = get-OVStorageVolume | where name -eq  'NHITS-ESXI-Boot (6629)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NHITS-ESXI-Boot (6629)"   -Capacity 5  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NHITS-ESXI-Boot (6629) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume NHITS-ESXI-Boot (9433) "
$vol                                       = get-OVStorageVolume | where name -eq  'NHITS-ESXI-Boot (9433)' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "NHITS-ESXI-Boot (9433)"   -Capacity 5  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume NHITS-ESXI-Boot (9433) already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume Node Storage 1 "
$vol                                       = get-OVStorageVolume | where name -eq  'Node Storage 1' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "Node Storage 1"   -Capacity 300  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume Node Storage 1 already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume Node Storage 2 "
$vol                                       = get-OVStorageVolume | where name -eq  'Node Storage 2' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "Node Storage 2"   -Capacity 300  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume Node Storage 2 already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume Node Storage GPU "
$vol                                       = get-OVStorageVolume | where name -eq  'Node Storage GPU' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "Node Storage GPU"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume Node Storage GPU already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume OpenStackBoot "
$vol                                       = get-OVStorageVolume | where name -eq  'OpenStackBoot' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "OpenStackBoot"   -Capacity 300  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume OpenStackBoot already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume OpenStackPikeAnsible "
$vol                                       = get-OVStorageVolume | where name -eq  'OpenStackPikeAnsible' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "OpenStackPikeAnsible"   -Capacity 160  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume OpenStackPikeAnsible already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume PrevinetTEmplate "
$vol                                       = get-OVStorageVolume | where name -eq  'PrevinetTEmplate' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "PrevinetTEmplate"   -Capacity 100  -StoragePool $stp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume PrevinetTEmplate already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume SSD-EPIC-controller1 "
$vol                                       = get-OVStorageVolume | where name -eq  'SSD-EPIC-controller1' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "SSD-EPIC-controller1"   -Capacity 600  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume SSD-EPIC-controller1 already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume Synergy VMFS 1 "
$vol                                       = get-OVStorageVolume | where name -eq  'Synergy VMFS 1' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "Synergy VMFS 1"   -Capacity 2000  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  -Shared  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume Synergy VMFS 1 already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume Synergy VMFS HA "
$vol                                       = get-OVStorageVolume | where name -eq  'Synergy VMFS HA' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "Synergy VMFS HA"   -Capacity 10  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  -Shared  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume Synergy VMFS HA already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume SynergyVMFS2 "
$vol                                       = get-OVStorageVolume | where name -eq  'SynergyVMFS2' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "SynergyVMFS2"   -Capacity 2000  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  -Shared  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume SynergyVMFS2 already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume VMFS OV4VC "
$vol                                       = get-OVStorageVolume | where name -eq  'VMFS OV4VC' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
        $sstp                              = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
        $sstp                              = if ($sstp -ne $Null) { $sstp } else {$stp}
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "VMFS OV4VC"   -Capacity 300  -StoragePool $stp  -SnapshotStoragePool $sstp  -storageSystem $sts  `
             -ProvisioningType "Thin"  -Shared  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume VMFS OV4VC already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume VMFS SSD "
$vol                                       = get-OVStorageVolume | where name -eq  'VMFS SSD' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.SSD.R5' 
    if ( $Null -ne $stp)
    {
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "VMFS SSD"   -Capacity 300.25  -StoragePool $stp  -storageSystem $sts  `
             -ProvisioningType "Thin"  -Shared  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.SSD.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume VMFS SSD already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume Vmworld 1 "
$vol                                       = get-OVStorageVolume | where name -eq  'Vmworld 1' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "Vmworld 1"   -Capacity 50.12  -StoragePool $stp  -storageSystem $sts  `
             -ProvisioningType "Thin"  -Shared  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume Vmworld 1 already exists. skip creating volume" 
}
write-host -foreground CYAN "----- Creating Storage Volume Vmworld 2 "
$vol                                       = get-OVStorageVolume | where name -eq  'Vmworld 2' 
if ($Null -eq $vol)
{
    $stp                                   = get-OVStoragePool | where name -eq  'ETSS.FC.R5' 
    if ( $Null -ne $stp)
    {
         # ----- Get Storage System
        $sts                               = get-OVStorageSystem | where name -eq  'PHA-7440-01' 
        new-OVStorageVolume  -Name "Vmworld 2"   -Capacity 50.12  -StoragePool $stp  -storageSystem $sts  `
             -ProvisioningType "Thin"  -Shared  `
             `
            


    }
    else
    {
        write-host -foreground YELLOW "storage pool ETSS.FC.R5 does not exist. Cannot create volume template"


    }
} # 
else
{
    write-host -foreground YELLOW "volume Vmworld 2 already exists. skip creating volume" 
}
Disconnect-OVMgmt
