﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD EPIC5-Gwy "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'EPIC5-Gwy' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F1-CN75140CR5, bay 5' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "EPIC5-Gwy"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F1-CN75140CR5, bay 5 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD EPIC5-Gwy already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD EPIC5-Gwy (2858) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'EPIC5-Gwy (2858)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F3-CN75140CR6, bay 3' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "EPIC5-Gwy (2858)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F3-CN75140CR6, bay 3 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD EPIC5-Gwy (2858) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD EPIC-Boot (2395) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'EPIC-Boot (2395)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F3-CN75140CR6, bay 3' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "EPIC-Boot (2395)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 1200 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F3-CN75140CR6, bay 3 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD EPIC-Boot (2395) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD EPIC-Boot (2396) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'EPIC-Boot (2396)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F1-CN75140CR5, bay 5' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "EPIC-Boot (2396)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 1200 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F1-CN75140CR5, bay 5 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD EPIC-Boot (2396) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD EPIC-Boot (3370) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'EPIC-Boot (3370)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F1-CN75140CR5, bay 5' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "EPIC-Boot (3370)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 1200 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F1-CN75140CR5, bay 5 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD EPIC-Boot (3370) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD EPIC-Boot (4580) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'EPIC-Boot (4580)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F3-CN75140CR6, bay 3' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "EPIC-Boot (4580)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 1200 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F3-CN75140CR6, bay 3 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD EPIC-Boot (4580) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD EPIC-Boot (4955) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'EPIC-Boot (4955)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F3-CN75140CR6, bay 3' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "EPIC-Boot (4955)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 1200 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F3-CN75140CR6, bay 3 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD EPIC-Boot (4955) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD EPIC-Boot (5641) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'EPIC-Boot (5641)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F1-CN75140CR5, bay 5' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "EPIC-Boot (5641)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 1200 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F1-CN75140CR5, bay 5 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD EPIC-Boot (5641) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD EPIC-Boot (7743) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'EPIC-Boot (7743)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F3-CN75140CR6, bay 3' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "EPIC-Boot (7743)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 1200 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F3-CN75140CR6, bay 3 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD EPIC-Boot (7743) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD EPIC-Boot (9276) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'EPIC-Boot (9276)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F1-CN75140CR5, bay 5' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "EPIC-Boot (9276)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 1200 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F1-CN75140CR5, bay 5 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD EPIC-Boot (9276) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Node-Jbod (0991) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Node-Jbod (0991)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F1-CN75140CR5, bay 5' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Node-Jbod (0991)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F1-CN75140CR5, bay 5 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Node-Jbod (0991) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Node-Jbod (4833) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Node-Jbod (4833)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F3-CN75140CR6, bay 3' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Node-Jbod (4833)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F3-CN75140CR6, bay 3 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Node-Jbod (4833) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Node-Jbod (5055) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Node-Jbod (5055)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F3-CN75140CR6, bay 3' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Node-Jbod (5055)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F3-CN75140CR6, bay 3 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Node-Jbod (5055) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Node-Jbod (5293) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Node-Jbod (5293)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F1-CN75140CR5, bay 5' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Node-Jbod (5293)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F1-CN75140CR5, bay 5 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Node-Jbod (5293) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Node-Jbod (5790) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Node-Jbod (5790)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F3-CN75140CR6, bay 3' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Node-Jbod (5790)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F3-CN75140CR6, bay 3 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Node-Jbod (5790) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Node-Jbod (7712) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Node-Jbod (7712)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F1-CN75140CR5, bay 5' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Node-Jbod (7712)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F1-CN75140CR5, bay 5 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Node-Jbod (7712) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Node-Jbod (8271) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Node-Jbod (8271)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F1-CN75140CR5, bay 5' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Node-Jbod (8271)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F1-CN75140CR5, bay 5 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Node-Jbod (8271) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Node-Jbod (9577) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Node-Jbod (9577)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F3-CN75140CR6, bay 3' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Node-Jbod (9577)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F3-CN75140CR6, bay 3 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Node-Jbod (9577) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Node-Storage (0994) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Node-Storage (0994)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F3-CN75140CR6, bay 3' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Node-Storage (0994)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F3-CN75140CR6, bay 3 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Node-Storage (0994) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Node-Storage (1555) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Node-Storage (1555)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F3-CN75140CR6, bay 3' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Node-Storage (1555)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F3-CN75140CR6, bay 3 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Node-Storage (1555) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Node-Storage (3591) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Node-Storage (3591)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F1-CN75140CR5, bay 5' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Node-Storage (3591)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F1-CN75140CR5, bay 5 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Node-Storage (3591) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Node-Storage (3629) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Node-Storage (3629)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F1-CN75140CR5, bay 5' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Node-Storage (3629)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F1-CN75140CR5, bay 5 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Node-Storage (3629) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Node-Storage (7193) "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Node-Storage (7193)' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F1-CN75140CR5, bay 5' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Node-Storage (7193)"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 2 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  -eraseDataOnDelete $True 
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F1-CN75140CR5, bay 5 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Node-Storage (7193) already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Test VB "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Test VB' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F1-CN75140CR5, bay 5' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Test VB"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 1 -MinDriveSize 1 -MaxDriveSize 300 `
                             -DriveType SAS  
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F1-CN75140CR5, bay 5 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Test VB already exists. skip creating JBOD" 
}
# ----------------------------------------------------------------
write-host -foreground CYAN "----- Creating Logical JBOD Windows Dung "
$jbod                                      = get-OVLogicalJBOD| where name -eq  'Windows Dung' 
if ($Null -eq $jbod )
{
    $driveEnclosure                        = Get-OVDriveEnclosure | where name -eq  'F3-CN75140CR6, bay 3' 
    if ( $Null -ne $driveEnclosure )
    {
        New-OVLogicalJbod	 -Name "Windows Dung"   `
                             -InputObject $driveEnclosure `
                             -NumberofDrives 1 -MinDriveSize 1 -MaxDriveSize 400 `
                             -DriveType SASSSD  
    } # 
    else
    {
        write-host -foreground YELLOW "No such drive enclosure F3-CN75140CR6, bay 3 to create JBOD."
    }
} # if $Null -eq $jbod 
else
{
    write-host -foreground YELLOW "logical JBOD Windows Dung already exists. skip creating JBOD" 
}
Disconnect-OVMgmt
