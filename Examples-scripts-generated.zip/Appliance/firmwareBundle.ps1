﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


write-host -foreground CYAN "----- Adding firmware Baseline HPE Synergy Custom SPP 201909 2019 09 25 "
Add-OVBaseline -file  "HPE_Synergy_Custom_SPP_2019_09_20190925_Z7550-96769.iso"


write-host -foreground CYAN "----- Adding firmware Baseline HPE Synergy Custom SPP 202005 2020 05 15 "
Add-OVBaseline -file  "HPE_Synergy_Custom_SPP_2020_05_01_Z7550-96878.iso"


write-host -foreground CYAN "----- Adding firmware Baseline Service Pack for Synergy "
Add-OVBaseline -file  "Synergy_Custom_SPP_2020_07_02_Z7550-97031.iso"


Disconnect-OVMgmt
