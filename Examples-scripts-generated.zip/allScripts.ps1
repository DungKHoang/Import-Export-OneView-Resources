﻿

#----------------------------------------------
#              OV Resources 					 
#----------------------------------------------


# ------ Step 1 - Create firmware Baseline script
C:\Scripts\Export-Import\Appliance\firmwareBundle.ps1


# ------ Step 2 - Create address pool script
C:\Scripts\Export-Import\Settings\addressPool.ps1


# ------ Step 3 - Create Ethernet network script
C:\Scripts\Export-Import\Networking\ethernetNetwork.ps1


# ------ Step 4 - Create FC network script
C:\Scripts\Export-Import\Networking\fcNetwork.ps1


# ------ Step 5 - Create network set script
C:\Scripts\Export-Import\Networking\networkSet.ps1


# ------ Step 6 - Create logical interconnect group script
C:\Scripts\Export-Import\Networking\logicalInterconnectGroup.ps1


# ------ Step 7 - Create uplink set script
C:\Scripts\Export-Import\Networking\uplinkSet.ps1


# ------ Step 8 - Create storage systems script
C:\Scripts\Export-Import\Storage\storageSystem.ps1


# ------ Step 9 - Create storage volume templates script
C:\Scripts\Export-Import\Storage\storageVolumeTemplate.ps1


# ------ Step 10 - Create storage volumes script
C:\Scripts\Export-Import\Storage\storageVolume.ps1


# ------ Step 11 - Create logical JBODs script
C:\Scripts\Export-Import\Storage\logicalJBOD.ps1


# ------ Step 12 - Create enclosure group script
C:\Scripts\Export-Import\Servers\enclosureGroup.ps1


# ------ Step 13 - Create logical enclosure script
C:\Scripts\Export-Import\Servers\LE.ps1


# ------ Step 14 - Create profile template script
C:\Scripts\Export-Import\Servers\profileTemplate.ps1


# ------ Step 15 - Create profile script
C:\Scripts\Export-Import\Servers\profileGroup1.PS1


# ------ Step 15 - Create profile script
C:\Scripts\Export-Import\Servers\profileGroup2.PS1


# ------ Step 15 - Create profile script
C:\Scripts\Export-Import\Servers\profileGroup3.PS1


# ------ Step 15 - Create profile script
C:\Scripts\Export-Import\Servers\profileGroup4.PS1




#----------------------------------------------
#              OV Settings					 
#----------------------------------------------


# ------ Create time & locale script
C:\Scripts\Export-Import\Settings\timeLocale.ps1


# ------ Create backup config script
C:\Scripts\Export-Import\Settings\backupConfig.ps1


# ------ Create external repository script
C:\Scripts\Export-Import\Settings\repository.ps1


# ------ Create scope script
C:\Scripts\Export-Import\Settings\scope.ps1


# ------ Create snmp Users script
C:\Scripts\Export-Import\Settings\snmpV3User.ps1


# ------ Create snmp traps script
C:\Scripts\Export-Import\Settings\snmpTrap.ps1




#----------------------------------------------
#              TBD -OV Appliance configuration		 
#----------------------------------------------


