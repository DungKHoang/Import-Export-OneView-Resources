﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


write-host -foreground CYAN "----- Creating logical enclosure LE "
$le                                        = get-OVLogicalEnclosure | where name -eq  'LE' 
if ($le -eq $Null)
{
    # -------------- Attributes for logical enclosure LE 


    # -- Renaming enclosures  
    $serialNumbers                         = @('CN75140CR5','CN75140CR6','CN7515049D')
    $enclosureNames                        = @('F1-CN75140CR5','F3-CN75140CR6','F2-CN7515049D')
    for ($i=0; $i -lt $serialNumbers.Count; $i++)
    {
        $this_enclosure                    = Get-OVEnclosure | where serialNumber -Match $serialNumbers[$i]
        if ( ($this_enclosure) -and ($enclosureNames -notcontains ($this_enclosure.Name) ) ) 
        {
            Set-OVEnclosure -inputObject $this_enclosure -Name $enclosureNames[$i]
        } # 
    }
    $enclosure                             = Get-OVEnclosure | where serialNumber -match 'CN75140CR5' 
    $enclosureGroup                        = Get-OVEnclosureGroup -name 'EG 3 frames' 


    New-OVLogicalEnclosure -Name "LE"  -Enclosure $enclosure -EnclosureGroup $enclosureGroup
} # 
else
{
    write-host -foreground YELLOW LE already exists.
}


Disconnect-OVMgmt
