﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


write-host -foreground CYAN "----- Creating logical enclosure 10.01.4-enclosure "
$le                                        = get-OVLogicalEnclosure | where name -eq  '10.01.4-enclosure' 
if ($le -eq $Null)
{
    # -------------- Attributes for logical enclosure 10.01.4-enclosure 
    $enclosure                             = Get-OVEnclosure | where serialNumber -match '0000A66101' 
    $enclosureGroup                        = Get-OVEnclosureGroup -name 'EG 3 frames' 
    $Ebipa                                 = @{
        Frame1 = @{
            Device3=@{IPv4Address='10.10.4.13'};
            Interconnect6=@{IPv4Address='10.10.4.16'}
                 };
        Frame2 = @{
            Device5=@{IPv4Address='10.10.4.25'};
            Interconnect4=@{IPv4Address='10.10.4.24'}
                 };
        Frame3 = @{
            Device8=@{IPv4Address='10.10.4.38'};
            Interconnect4=@{IPv4Address='10.10.4.34'}
                 }
                                              }


    New-OVLogicalEnclosure -Name "10.01.4-enclosure"  -Enclosure $enclosure -EnclosureGroup $enclosureGroup `
                             `
                             -ebipa $ebipa  `


} # 
else
{
    write-host -foreground YELLOW 10.01.4-enclosure already exists.
}


Disconnect-OVMgmt
