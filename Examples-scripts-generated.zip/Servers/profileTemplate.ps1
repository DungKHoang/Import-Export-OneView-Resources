﻿class sasJBOD
{
    [int]$id
    [string]$deviceSlot
    [string]$name
    [string]$description
    [int]$numPhysicalDrives
    [string]$driveMinSizeGB
    [string]$driveMaxSizeGB
    [string]$driveTechnology
    [boolean]$eraseData
    [boolean]$persistent
    [string]$sasLogicalJBODUri
}


write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


write-host -foreground CYAN "----- Creating profile 660 vSphere template "
$profile                                   = get-OVServerProfileTemplate | where name -eq  '660 vSphere template' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile  
    $name                                  = '660 vSphere template'
    $spDescription                         = 'F3-2'
    $sht                                   = Get-OVserverHardwareType -name 'SY 660 Gen9 1'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "None"
    $network                               = Get-OVnetwork | where name -eq 'Mgmt' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Mgmt' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Mgmt A"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Mgmt' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Mgmt' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "Mgmt B"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'vMotion' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'vMotion' 
    } # 
    $conn3   = New-OVServerProfileConnection  -name "vMotion A"  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'vMotion' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'vMotion' 
    } # 
    $conn4   = New-OVServerProfileConnection  -name "vMotion B"  -ConnectionID 4 `
                                              -PortId "Mezz 3:2-c" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Deployment' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Deployment' 
    } # 
    $conn5   = New-OVServerProfileConnection  -name "Deployment A"  -ConnectionID 5 `
                                              -PortId "Mezz 3:1-d" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Deployment' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Deployment' 
    } # 
    $conn6   = New-OVServerProfileConnection  -name "Deployment B"  -ConnectionID 6 `
                                              -PortId "Mezz 3:2-d" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'FC Discover top' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'FC Discover top' 
    } # 
    $conn7   = New-OVServerProfileConnection  -name "FC top"  -ConnectionID 7 `
                                              -PortId "Mezz 3:1-b" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'FC Discover bottom' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'FC Discover bottom' 
    } # 
    $conn8   = New-OVServerProfileConnection  -name "FC bottom"  -ConnectionID 8 `
                                              -PortId "Mezz 3:2-b" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2,$conn3,$conn4,$conn5,$conn6,$conn7,$conn8)


    # -------------- Local Storage section 
    $lsConsistencyChecking                 = "None"


    # --- Search for SAS-Logical-Interconnect for SASlogicalJBOD 
    $ligAssociation                        = Search-OVAssociations ENCLOSURE_GROUP_TO_LOGICAL_INTERCONNECT_GROUP -parent $eg
    $sasLigUri                             = ($ligAssociation | where ChildUri -like "*sas*").ChildUri
    $sasLig                                = if ($sasLigUri) { Send-OVRequest -uri $sasLigUri } else {$Null}
    $sasUri                                = (Search-OVAssociations LOGICAL_INTERCONNECT_GROUP_TO_LOGICAL_INTERCONNECT -Parent $sasLig).childUri[0]
    $sasLI                                 = if ($sasUri) { Send-OVRequest -uri $sasUri } else {$Null}
    $lsJBOD                                = [System.Collections.ArrayList]::new()


    # --- Attributes for Logical Disk Logical Drive 1 (Embedded)
    $ldName                                = 'Logical Drive 1'
    $bootable                              = $False
    $raidLevel                             = 'RAID10'
    $driveType                             = 'Sas'
    $numberofDrives                        = 4
    $accelerator                           = 'Unmanaged'
    $LogicalDisk1                          = New-OVServerProfileLogicalDisk  -Name $ldName -Bootable $bootable -RAID $raidLevel -DriveType $driveType -NumberofDrives $numberofDrives  -Accelerator $accelerator 
    $logicalDisks                          = @($LogicalDisk1)
    $controller1                           = New-OVServerProfileLogicalDiskController  -ControllerID "Embedded" -Mode "RAID" -Initialize:$True -WriteCache "Unmanaged"  -LogicalDisk $LogicalDisks 


    $controllers                           = @($controller1)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -ServerProfileDescription $spDescription -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `
                                     -StorageController $controllers `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "660 vSphere template already exists." 
}


write-host -foreground CYAN "----- Creating profile AZUR-G9 "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'AZUR-G9' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile FC bottom 
    $name                                  = 'AZUR-G9'
    $description                           = 'AZUR Template'
    $spDescription                         = 'AZUR Template'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Public-HOL-Net' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Public-HOL-Net' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "1"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Public-HOL-Net' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Public-HOL-Net' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "2"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2)


    # -------------- Local Storage section 
    $lsConsistencyChecking                 = "None"


    # --- Search for SAS-Logical-Interconnect for SASlogicalJBOD 
    $ligAssociation                        = Search-OVAssociations ENCLOSURE_GROUP_TO_LOGICAL_INTERCONNECT_GROUP -parent $eg
    $sasLigUri                             = ($ligAssociation | where ChildUri -like "*sas*").ChildUri
    $sasLig                                = if ($sasLigUri) { Send-OVRequest -uri $sasLigUri } else {$Null}
    $sasUri                                = (Search-OVAssociations LOGICAL_INTERCONNECT_GROUP_TO_LOGICAL_INTERCONNECT -Parent $sasLig).childUri[0]
    $sasLI                                 = if ($sasUri) { Send-OVRequest -uri $sasUri } else {$Null}
    $lsJBOD                                = [System.Collections.ArrayList]::new()


    # --- Attributes for Logical Disk Boot (Embedded)
    $ldName                                = 'Boot'
    $bootable                              = $True
    $raidLevel                             = 'RAID1'
    $driveType                             = 'Auto'
    $numberofDrives                        = 2
    $accelerator                           = 'Unmanaged'
    $LogicalDisk1                          = New-OVServerProfileLogicalDisk  -Name $ldName -Bootable $bootable -RAID $raidLevel -DriveType $driveType -NumberofDrives $numberofDrives  -Accelerator $accelerator 
    $logicalDisks                          = @($LogicalDisk1)
    $controller1                           = New-OVServerProfileLogicalDiskController  -ControllerID "Embedded" -Mode "RAID" -Initialize:$True -WriteCache "Unmanaged"  -LogicalDisk $LogicalDisks 


    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod1                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD4 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod1)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 4
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD4
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod1.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod2                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD1 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod2)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 1
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD1
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod2.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod3                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD3 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod3)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 3
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD3
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod3.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod4                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD2 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod4)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 2
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD2
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod4.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    $controllers                           = @($controller1)


    # -------------- Boot mode section 
    $bootMode                              = "UEFI"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerProfileDescription $spDescription -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `
                                     -StorageController $controllers `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "AZUR-G9 already exists." 
}


write-host -foreground CYAN "----- Creating profile AZURG10 "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'AZURG10' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile 2 
    $name                                  = 'AZURG10'
    $description                           = 'AZUR Template'
    $spDescription                         = 'AZUR Template'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen10 1'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Public-HOL-Net' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Public-HOL-Net' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "1"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Public-HOL-Net' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Public-HOL-Net' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "2"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2)


    # -------------- Local Storage section 
    $lsConsistencyChecking                 = "Exact"


    # --- Search for SAS-Logical-Interconnect for SASlogicalJBOD 
    $ligAssociation                        = Search-OVAssociations ENCLOSURE_GROUP_TO_LOGICAL_INTERCONNECT_GROUP -parent $eg
    $sasLigUri                             = ($ligAssociation | where ChildUri -like "*sas*").ChildUri
    $sasLig                                = if ($sasLigUri) { Send-OVRequest -uri $sasLigUri } else {$Null}
    $sasUri                                = (Search-OVAssociations LOGICAL_INTERCONNECT_GROUP_TO_LOGICAL_INTERCONNECT -Parent $sasLig).childUri[0]
    $sasLI                                 = if ($sasUri) { Send-OVRequest -uri $sasUri } else {$Null}
    $lsJBOD                                = [System.Collections.ArrayList]::new()
    $controller1                           = New-OVServerProfileLogicalDiskController  -ControllerID "Mezz 1" -Mode "Mixed" -Initialize:$True -WriteCache "Unmanaged" 


    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod1                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD2 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod1)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 9
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD2
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod1.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod2                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD1 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod2)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 8
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD1
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod2.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod3                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD4 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod3)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 11
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD4
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod3.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod4                         = new-OVLogicalJBOD -InputObject $sasLI  -name boot -driveType SasSsd -MinDriveSize 400 -MaxDriveSize 400 -EraseDataOneDelete $True  
            if ($jbod4)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 12
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = boot
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 400
                $_jbod.driveMaxSizeGB      = 400
                $_jbod.driveTechnology     = SasSsd
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod4.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod5                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD3 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod5)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 10
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD3
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod5.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    $controllers                           = @($controller1)


    # -------------- Boot mode section 
    $bootMode                              = "BIOS"
    $bootOrder                             = @('CD','USB','HardDisk','PXE')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    # -------------- BIOS section 
    $biosSettings                          = @(
        @{ id = "Sriov"; value = "Enabled"},
        @{ id = "IntelProcVtd"; value = "Enabled"},
        @{ id = "ProcVirtualization"; value = "Enabled"}
        )
    $biosConsistency                       = "None"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerProfileDescription $spDescription -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Bios -BiosSettings $biosSettings -BiosConsistencyChecking $biosConsistency `
                                     -Connections $connectionList  `
                                     -StorageController $controllers `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "AZURG10 already exists." 
}


write-host -foreground CYAN "----- Creating profile AZURG10-noHBA "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'AZURG10-noHBA' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile 2 
    $name                                  = 'AZURG10-noHBA'
    $description                           = 'AZUR Template'
    $spDescription                         = 'AZUR Template'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen10 1'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Public-HOL-Net' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Public-HOL-Net' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "1"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Public-HOL-Net' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Public-HOL-Net' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "2"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2)


    # -------------- Local Storage section 
    $lsConsistencyChecking                 = "Exact"


    # --- Search for SAS-Logical-Interconnect for SASlogicalJBOD 
    $ligAssociation                        = Search-OVAssociations ENCLOSURE_GROUP_TO_LOGICAL_INTERCONNECT_GROUP -parent $eg
    $sasLigUri                             = ($ligAssociation | where ChildUri -like "*sas*").ChildUri
    $sasLig                                = if ($sasLigUri) { Send-OVRequest -uri $sasLigUri } else {$Null}
    $sasUri                                = (Search-OVAssociations LOGICAL_INTERCONNECT_GROUP_TO_LOGICAL_INTERCONNECT -Parent $sasLig).childUri[0]
    $sasLI                                 = if ($sasUri) { Send-OVRequest -uri $sasUri } else {$Null}
    $lsJBOD                                = [System.Collections.ArrayList]::new()
    $controller1                           = New-OVServerProfileLogicalDiskController  -ControllerID "Mezz 1" -Mode "Mixed" -Initialize:$True -WriteCache "Unmanaged" 


    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod1                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD4 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod1)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 3
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD4
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod1.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod2                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD3 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod2)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 2
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD3
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod2.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod3                         = new-OVLogicalJBOD -InputObject $sasLI  -name boot -driveType SasSsd -MinDriveSize 400 -MaxDriveSize 400 -EraseDataOneDelete $True  
            if ($jbod3)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 1
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = boot
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 400
                $_jbod.driveMaxSizeGB      = 400
                $_jbod.driveTechnology     = SasSsd
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod3.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod4                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD1 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod4)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 4
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD1
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod4.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod5                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD2 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod5)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 5
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD2
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod5.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    $controllers                           = @($controller1)


    # -------------- Boot mode section 
    $bootMode                              = "BIOS"
    $bootOrder                             = @('CD','USB','HardDisk','PXE')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    # -------------- BIOS section 
    $biosSettings                          = @(
        @{ id = "Sriov"; value = "Enabled"},
        @{ id = "IntelProcVtd"; value = "Enabled"},
        @{ id = "ProcVirtualization"; value = "Enabled"}
        )
    $biosConsistency                       = "None"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerProfileDescription $spDescription -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Bios -BiosSettings $biosSettings -BiosConsistencyChecking $biosConsistency `
                                     -Connections $connectionList  `
                                     -StorageController $controllers `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "AZURG10-noHBA already exists." 
}


write-host -foreground CYAN "----- Creating profile Centos "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'Centos' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile 2 
    $name                                  = 'Centos'
    $description                           = 'Centos folding'
    $spDescription                         = 'CentOS-Folding'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "None"
    $network                               = Get-OVnetwork | where name -eq 'Public-HOL-Net' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Public-HOL-Net' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Public"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'FC Discover top' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'FC Discover top' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "FiberA"  -ConnectionID 2 `
                                              -PortId "Mezz 3:1-b" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Primary -bootVolumeSource ManagedVolume   


    $network                               = Get-OVnetwork | where name -eq 'FC Discover bottom' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'FC Discover bottom' 
    } # 
    $conn3   = New-OVServerProfileConnection  -name "FiberB"  -ConnectionID 3 `
                                              -PortId "Mezz 3:2-b" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Secondary -bootVolumeSource ManagedVolume   


    $connectionList                        = @($conn1,$conn2,$conn3)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerProfileDescription $spDescription -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy IPv4 -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "Centos already exists." 
}


write-host -foreground CYAN "----- Creating profile Chef-Bootstrap-SPT "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'Chef-Bootstrap-SPT' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile FiberB 
    $name                                  = 'Chef-Bootstrap-SPT'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Mgmt"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "Chef-Bootstrap-SPT already exists." 
}


write-host -foreground CYAN "----- Creating profile Chef-DCOS-SPT "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'Chef-DCOS-SPT' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile Mgmt 
    $name                                  = 'Chef-DCOS-SPT'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Mgmt"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "Chef-DCOS-SPT already exists." 
}


write-host -foreground CYAN "----- Creating profile DC/OS "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'DC/OS' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile Mgmt 
    $name                                  = 'DC/OS'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Management A"  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "Management B"  -ConnectionID 4 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "DC/OS already exists." 
}


write-host -foreground CYAN "----- Creating profile DCOS Master Node33 "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'DCOS Master Node33' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile Management B 
    $name                                  = 'DCOS Master Node33'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"


    # -------------- Boot mode section 
    $bootMode                              = "BIOS"
    $bootOrder                             = @('CD','USB','HardDisk','PXE')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -manageConnections $manageConnections -ConnectionsConsistencyChecking $connectionsConsistency `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "DCOS Master Node33 already exists." 
}


write-host -foreground CYAN "----- Creating profile DCOS Node Template "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'DCOS Node Template' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile Management B 
    $name                                  = 'DCOS Node Template'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Mgmt A"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1)


    # -------------- Boot mode section 
    $bootMode                              = "UEFI"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "DCOS Node Template already exists." 
}


write-host -foreground CYAN "----- Creating profile Docker UCP "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'Docker UCP' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile Mgmt A 
    $name                                  = 'Docker UCP'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Management A"  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "Management B"  -ConnectionID 4 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "Docker UCP already exists." 
}


write-host -foreground CYAN "----- Creating profile Docker UCP with I3S connections "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'Docker UCP with I3S connections' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile Management B 
    $name                                  = 'Docker UCP with I3S connections'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Management A"  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "Management B"  -ConnectionID 4 `
                                              -PortId "Mezz 3:2-c" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "Docker UCP with I3S connections already exists." 
}


write-host -foreground CYAN "----- Creating profile DockerTemplateonSY660Gen9-1 "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'DockerTemplateonSY660Gen9-1' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile Management B 
    $name                                  = 'DockerTemplateonSY660Gen9-1'
    $description                           = 'docker'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Management_A"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "Management_B"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-c" -RequestedBW 4000 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    # -------------- BIOS section 
    $biosSettings                          = @(
        @{ id = "ProcHyperthreading"; value = "Enabled"},
        @{ id = "PowerRegulator"; value = "StaticHighPerf"},
        @{ id = "PowerProfile"; value = "Custom"}
        )
    $biosConsistency                       = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Bios -BiosSettings $biosSettings -BiosConsistencyChecking $biosConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "DockerTemplateonSY660Gen9-1 already exists." 
}


write-host -foreground CYAN "----- Creating profile dung-spt-ilo "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'dung-spt-ilo' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile Management_B 
    $name                                  = 'dung-spt-ilo'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen10 1'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "None"


    # -------------- iLO section 
    $manageIlo                             = $True
    $iloConsistency                        = "Exact"
    $iloUser1                              = new-OVIloLocalUserAccount	 -Username 'dung'  -DisplayName 'dung'  `
                                                                         -Password $("***REDACTED***" | ConvertTo-SecureString -AsPlainText -Force )  `
                                                                         -AdministerUserAccounts $True  `
                                                                         -RemoteConsole $True  `
                                                                         -VirtualMedia $True  `
                                                                         -ConfigureIloSettings $True  `
                                                                         -VirtualPowerAndReset $True  `
                                                                         -Login $True  `
                                                                         -HostBIOS $True  `
                                                                         -HostNIC $True  `
                                                                         -HostStorage $True  `


    $iloLocalAccounts                      = @($iloUser1)
    $iloPolicy                             = new-OVServerProfileIloPolicy	 `
                                                                             -ManageLocalAccounts -LocalAccounts $iloLocalAccounts  `




    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -manageConnections $manageConnections -ConnectionsConsistencyChecking $connectionsConsistency `
                                     -ManageIloSettings $manageIlo -IloSettingsConsistencyChecking $iloConsistency -IloSettings $iloPolicy 


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "dung-spt-ilo already exists." 
}


write-host -foreground CYAN "----- Creating profile Dung-Test-Capture-VMware "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'Dung-Test-Capture-VMware' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile Management_B 
    $name                                  = 'Dung-Test-Capture-VMware'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen10 1'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "None"
    $network                               = Get-OVnetwork | where name -eq 'IS iSCSI' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'IS iSCSI' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Deployment Network A"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Primary -bootVolumeSource UserDefined   


    $network                               = Get-OVnetwork | where name -eq 'IS iSCSI' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'IS iSCSI' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "Deployment Network B"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Secondary -bootVolumeSource UserDefined   


    $network                               = Get-OVnetwork | where name -eq 'Corporate 16' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Corporate 16' 
    } # 
    $conn3   = New-OVServerProfileConnection  -name "prod"  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Secondary -bootVolumeSource UserDefined   


    $connectionList                        = @($conn1,$conn2,$conn3)


    # -------------- Local Storage section 
    $lsConsistencyChecking                 = "None"


    # --- Search for SAS-Logical-Interconnect for SASlogicalJBOD 
    $ligAssociation                        = Search-OVAssociations ENCLOSURE_GROUP_TO_LOGICAL_INTERCONNECT_GROUP -parent $eg
    $sasLigUri                             = ($ligAssociation | where ChildUri -like "*sas*").ChildUri
    $sasLig                                = if ($sasLigUri) { Send-OVRequest -uri $sasLigUri } else {$Null}
    $sasUri                                = (Search-OVAssociations LOGICAL_INTERCONNECT_GROUP_TO_LOGICAL_INTERCONNECT -Parent $sasLig).childUri[0]
    $sasLI                                 = if ($sasUri) { Send-OVRequest -uri $sasUri } else {$Null}
    $lsJBOD                                = [System.Collections.ArrayList]::new()


    # --- Attributes for Logical Disk logical (Mezz 1)
    $ldName                                = 'logical'
    $bootable                              = $False
    $raidLevel                             = 'RAID1'
    $driveType                             = 'Sas'
    $numberofDrives                        = 2
    $accelerator                           = 'ControllerCache'
    $LogicalDisk1                          = New-OVServerProfileLogicalDisk  -Name $ldName -Bootable $bootable -RAID $raidLevel -DriveType $driveType -NumberofDrives $numberofDrives  -Accelerator $accelerator 
    $logicalDisks                          = @($LogicalDisk1)
    $controller1                           = New-OVServerProfileLogicalDiskController  -ControllerID "Mezz 1" -Mode "Mixed" -Initialize:$True -WriteCache "Unmanaged"  -LogicalDisk $LogicalDisks 


    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod1                         = new-OVLogicalJBOD -InputObject $sasLI  -name ExternalJBOD -driveType Sas -MinDriveSize 1200 -MaxDriveSize 1200 -EraseDataOneDelete $True  
            if ($jbod1)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 2
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = ExternalJBOD
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 1200
                $_jbod.driveMaxSizeGB      = 1200
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = True
                $_jbod.sasLogicalJBODUri   = $jbod1.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod2                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBO1 -driveType Sas -MinDriveSize 1200 -MaxDriveSize 1200 -EraseDataOneDelete $True  
            if ($jbod2)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 1
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBO1
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 1200
                $_jbod.driveMaxSizeGB      = 1200
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = True
                $_jbod.sasLogicalJBODUri   = $jbod2.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    $controllers                           = @($controller1)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    # -------------- iLO section 
    $manageIlo                             = $True
    $iloConsistency                        = "Exact"
    $iloUser1                              = new-OVIloLocalUserAccount	 -Username 'Dung1'  -DisplayName 'Dung1-display'  `
                                                                         -Password $("***REDACTED***" | ConvertTo-SecureString -AsPlainText -Force )  `
                                                                         -Login $True  `
                                                                         -HostBIOS $True  `
                                                                         -HostNIC $True  `
                                                                         -HostStorage $True  `


    $iloUser2                              = new-OVIloLocalUserAccount	 -Username 'Dung2'  -DisplayName 'Dung2-display'  `
                                                                         -Password $("***REDACTED***" | ConvertTo-SecureString -AsPlainText -Force )  `
                                                                         -AdministerUserAccounts $True  `
                                                                         -HostStorage $True  `


    $iloDG1                                = New-OVIloDirectoryGroup -GroupDN "ou=DG1, dc=domain, dc=com" -GroupSID 1234567890A `
                                                                         -AdministerUserAccounts $True  `
                                                                         -RemoteConsole $True  `
                                                                         -VirtualMedia $True  `
                                                                         -ConfigureIloSettings $True  `
                                                                         -VirtualPowerAndReset $True  `


    $iloDG2                                = New-OVIloDirectoryGroup -GroupDN "ou=DG2, dc=domain, dc=com" -GroupSID 1234567890B `
                                                                         -RemoteConsole $True  `


    $iloDG3                                = New-OVIloDirectoryGroup -GroupDN "ou=DG3, dc=domain, dc=com" -GroupSID 1234567890C `
                                                                         -AdministerUserAccounts $True  `


    $iloLocalAccounts                      = @($iloUser1,$iloUser2)
    $iloDirectoryGroups                    = @($iloDG1,$iloDG2,$iloDG3)
    $iloPolicy                             = new-OVServerProfileIloPolicy	 -ManageLocalAdministratorAccount  -RemoveLocalAdministratorAccount $False  `
                                                                             -ManageLocalAccounts -LocalAccounts $iloLocalAccounts  `
                                                                             -ManageDirectoryGroups -DirectoryGroups $iloDirectoryGroups  `
                                                                             -ManageIloHostname -IloHostname "{serverProfileName}-ilo"  `
                                                                             -ManageDirectoryConfiguration  `
                                                                             -LdapSchema DirectoryDefault -GenericLDAP $False  `
                                                                             -LOMObjectDistinguishedName "dn=lomobject, ou=OU1, dc=domain, dc=com"  `
                                                                             -IloObjectPassword $("***REDACTED***" | ConvertTo-SecureString -AsPlainText -Force)  `
                                                                             -DirectoryServerAddress 192.168.1.51 -DirectoryServerPort 636  `
                                                                             -DirectoryUserContext 'ou=OU1, dc=domain, dc=com' , 'ou=OU2, dc=domain, dc=com'  `
                                                                             -ManageKeyManager   `
                                                                             -PrimaryKeyServerAddress 192.168.1.51 -PrimaryKeyServerPort 9000  `
                                                                             -RedundancyRequired $False -KeymanagerGroupName EKMS `
                                                                             -KeymanagerLoginName administrator -KeymanagerPassword $("***REDACTED***" | ConvertTo-SecureString -AsPlainText -Force )  `




    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `
                                     -StorageController $controllers `
                                     -ManageIloSettings $manageIlo -IloSettingsConsistencyChecking $iloConsistency -IloSettings $iloPolicy 


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "Dung-Test-Capture-VMware already exists." 
}


write-host -foreground CYAN "----- Creating profile Dung-Test-Deploy-VMware "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'Dung-Test-Deploy-VMware' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile prod 
    $name                                  = 'Dung-Test-Deploy-VMware'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen10 1'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "None"
    $network                               = Get-OVnetwork | where name -eq 'IS iSCSI' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'IS iSCSI' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Deployment Network A"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Primary -bootVolumeSource UserDefined   


    $network                               = Get-OVnetwork | where name -eq 'IS iSCSI' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'IS iSCSI' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "Deployment Network B"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Secondary -bootVolumeSource UserDefined   


    $network                               = Get-OVnetwork | where name -eq 'Corporate 16' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Corporate 16' 
    } # 
    $conn3   = New-OVServerProfileConnection  -name "prod"  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Secondary -bootVolumeSource UserDefined   


    $connectionList                        = @($conn1,$conn2,$conn3)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "Dung-Test-Deploy-VMware already exists." 
}


write-host -foreground CYAN "----- Creating profile EPIC5 SRV - Gen9 "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'EPIC5 SRV - Gen9' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile prod 
    $name                                  = 'EPIC5 SRV - Gen9'
    $description                           = '2x SAN + 2x 300GB HDD BlueData EPIC 5 - Container Platform not for GWY srv'
    $spDescription                         = 'Blue Data EPIC 5 - Gen9'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "None"
    $network                               = Get-OVnetwork | where name -eq 'Public-HOL-Net' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Public-HOL-Net' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "1"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Deployment' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Deployment' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "2"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'FC Discover bottom' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'FC Discover bottom' 
    } # 
    $conn3   = New-OVServerProfileConnection  -name "FC1"  -ConnectionID 3 `
                                              -PortId "Mezz 3:2-b" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Primary -bootVolumeSource ManagedVolume   


    $network                               = Get-OVnetwork | where name -eq 'FC Discover top' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'FC Discover top' 
    } # 
    $conn4   = New-OVServerProfileConnection  -name "FC2"  -ConnectionID 4 `
                                              -PortId "Mezz 3:1-b" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Secondary -bootVolumeSource ManagedVolume   


    $connectionList                        = @($conn1,$conn2,$conn3,$conn4)


    # -------------- Local Storage section 
    $lsConsistencyChecking                 = "None"


    # --- Search for SAS-Logical-Interconnect for SASlogicalJBOD 
    $ligAssociation                        = Search-OVAssociations ENCLOSURE_GROUP_TO_LOGICAL_INTERCONNECT_GROUP -parent $eg
    $sasLigUri                             = ($ligAssociation | where ChildUri -like "*sas*").ChildUri
    $sasLig                                = if ($sasLigUri) { Send-OVRequest -uri $sasLigUri } else {$Null}
    $sasUri                                = (Search-OVAssociations LOGICAL_INTERCONNECT_GROUP_TO_LOGICAL_INTERCONNECT -Parent $sasLig).childUri[0]
    $sasLI                                 = if ($sasUri) { Send-OVRequest -uri $sasUri } else {$Null}
    $lsJBOD                                = [System.Collections.ArrayList]::new()
    $controller1                           = New-OVServerProfileLogicalDiskController  -ControllerID "Mezz 1" -Mode "HBA" -Initialize:$True -WriteCache "Unmanaged" 


    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod1                         = new-OVLogicalJBOD -InputObject $sasLI  -name Node-Storage -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod1)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 2
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = Node-Storage
                $_jbod.numPhysicalDrives   = 2
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod1.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    $controllers                           = @($controller1)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerProfileDescription $spDescription -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `
                                     -StorageController $controllers `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "EPIC5 SRV - Gen9 already exists." 
}


write-host -foreground CYAN "----- Creating profile EPIC5-SRV "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'EPIC5-SRV' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile FC2 
    $name                                  = 'EPIC5-SRV'
    $description                           = '1x 600GB SAN + 4x HDD 1.2 300 BlueData EPIC 5 - Container Platform not for GWY srv'
    $spDescription                         = 'Blue Data EPIC 5'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen10 1'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "None"
    $network                               = Get-OVnetwork | where name -eq 'Public-HOL-Net' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Public-HOL-Net' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "1"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Deployment' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Deployment' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "2"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'FC Discover bottom' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'FC Discover bottom' 
    } # 
    $conn3   = New-OVServerProfileConnection  -name "FC1"  -ConnectionID 3 `
                                              -PortId "Mezz 3:2-b" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'FC Discover top' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'FC Discover top' 
    } # 
    $conn4   = New-OVServerProfileConnection  -name "FC2"  -ConnectionID 4 `
                                              -PortId "Mezz 3:1-b" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2,$conn3,$conn4)


    # -------------- Local Storage section 
    $lsConsistencyChecking                 = "None"


    # --- Search for SAS-Logical-Interconnect for SASlogicalJBOD 
    $ligAssociation                        = Search-OVAssociations ENCLOSURE_GROUP_TO_LOGICAL_INTERCONNECT_GROUP -parent $eg
    $sasLigUri                             = ($ligAssociation | where ChildUri -like "*sas*").ChildUri
    $sasLig                                = if ($sasLigUri) { Send-OVRequest -uri $sasLigUri } else {$Null}
    $sasUri                                = (Search-OVAssociations LOGICAL_INTERCONNECT_GROUP_TO_LOGICAL_INTERCONNECT -Parent $sasLig).childUri[0]
    $sasLI                                 = if ($sasUri) { Send-OVRequest -uri $sasUri } else {$Null}
    $lsJBOD                                = [System.Collections.ArrayList]::new()
    $controller1                           = New-OVServerProfileLogicalDiskController  -ControllerID "Mezz 1" -Mode "Mixed" -Initialize:$True -WriteCache "Unmanaged" 


    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod1                         = new-OVLogicalJBOD -InputObject $sasLI  -name EPIC-Boot -driveType Sas -MinDriveSize 1200 -MaxDriveSize 1200 -EraseDataOneDelete $True  
            if ($jbod1)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 3
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = EPIC-Boot
                $_jbod.numPhysicalDrives   = 2
                $_jbod.driveMinSizeGB      = 1200
                $_jbod.driveMaxSizeGB      = 1200
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod1.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod2                         = new-OVLogicalJBOD -InputObject $sasLI  -name Node-Jbod -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod2)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 4
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = Node-Jbod
                $_jbod.numPhysicalDrives   = 2
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod2.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    $controllers                           = @($controller1)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerProfileDescription $spDescription -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy IPv4 -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `
                                     -StorageController $controllers `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "EPIC5-SRV already exists." 
}


write-host -foreground CYAN "----- Creating profile EPIC-SRV-GPU "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'EPIC-SRV-GPU' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile FC2 
    $name                                  = 'EPIC-SRV-GPU'
    $description                           = '4x SAN BlueData EPIC 5 - Container Platform not for GWY srv'
    $spDescription                         = 'Blue Data EPIC 5'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen10 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "None"
    $network                               = Get-OVnetwork | where name -eq 'Public-HOL-Net' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Public-HOL-Net' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "1"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Deployment' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Deployment' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "2"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'FC Discover top' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'FC Discover top' 
    } # 
    $conn3   = New-OVServerProfileConnection  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-b" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Primary -bootVolumeSource ManagedVolume   


    $network                               = Get-OVnetwork | where name -eq 'FC Discover bottom' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'FC Discover bottom' 
    } # 
    $conn4   = New-OVServerProfileConnection  -ConnectionID 4 `
                                              -PortId "Mezz 3:2-b" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Secondary -bootVolumeSource ManagedVolume   


    $connectionList                        = @($conn1,$conn2,$conn3,$conn4)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerProfileDescription $spDescription -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy IPv4 -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "EPIC-SRV-GPU already exists." 
}


write-host -foreground CYAN "----- Creating profile ESXi template for OV4VC demo "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'ESXi template for OV4VC demo' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile  
    $name                                  = 'ESXi template for OV4VC demo'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'ICSP' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'ICSP' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Deployment A"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Primary -bootVolumeSource    


    $network                               = Get-OVnetwork | where name -eq 'ICSP' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'ICSP' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "Deployment B"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Secondary -bootVolumeSource    


    $network                               = Get-OVnetwork | where name -eq 'Mgmt' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Mgmt' 
    } # 
    $conn3   = New-OVServerProfileConnection  -name "Management A"  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Secondary -bootVolumeSource    


    $network                               = Get-OVnetwork | where name -eq 'Mgmt' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Mgmt' 
    } # 
    $conn4   = New-OVServerProfileConnection  -name "Management B"  -ConnectionID 4 `
                                              -PortId "Mezz 3:2-c" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Secondary -bootVolumeSource    


    $network                               = Get-OVnetwork | where name -eq 'vMotion' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'vMotion' 
    } # 
    $conn5   = New-OVServerProfileConnection  -name "vMotion A"  -ConnectionID 5 `
                                              -PortId "Mezz 3:1-d" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Secondary -bootVolumeSource    


    $network                               = Get-OVnetwork | where name -eq 'vMotion' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'vMotion' 
    } # 
    $conn6   = New-OVServerProfileConnection  -name "vMotion B"  -ConnectionID 6 `
                                              -PortId "Mezz 3:2-d" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Secondary -bootVolumeSource    


    $network                               = Get-OVnetwork | where name -eq 'FC Discover top' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'FC Discover top' 
    } # 
    $conn7   = New-OVServerProfileConnection  -name "FC top"  -ConnectionID 7 `
                                              -PortId "Mezz 3:1-b" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Secondary -bootVolumeSource    


    $network                               = Get-OVnetwork | where name -eq 'FC Discover bottom' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'FC Discover bottom' 
    } # 
    $conn8   = New-OVServerProfileConnection  -name "FC bottom"  -ConnectionID 8 `
                                              -PortId "Mezz 3:2-b" -RequestedBW 2500 `
                                              -network $network  -bootable:$True -priority Secondary -bootVolumeSource    


    $connectionList                        = @($conn1,$conn2,$conn3,$conn4,$conn5,$conn6,$conn7,$conn8)


    # -------------- Local Storage section 
    $lsConsistencyChecking                 = "Exact"


    # --- Search for SAS-Logical-Interconnect for SASlogicalJBOD 
    $ligAssociation                        = Search-OVAssociations ENCLOSURE_GROUP_TO_LOGICAL_INTERCONNECT_GROUP -parent $eg
    $sasLigUri                             = ($ligAssociation | where ChildUri -like "*sas*").ChildUri
    $sasLig                                = if ($sasLigUri) { Send-OVRequest -uri $sasLigUri } else {$Null}
    $sasUri                                = (Search-OVAssociations LOGICAL_INTERCONNECT_GROUP_TO_LOGICAL_INTERCONNECT -Parent $sasLig).childUri[0]
    $sasLI                                 = if ($sasUri) { Send-OVRequest -uri $sasUri } else {$Null}
    $lsJBOD                                = [System.Collections.ArrayList]::new()


    # --- Attributes for Logical Disk LD1 (Embedded)
    $ldName                                = 'LD1'
    $bootable                              = $False
    $raidLevel                             = 'RAID1'
    $driveType                             = 'Auto'
    $numberofDrives                        = 2
    $accelerator                           = 'Unmanaged'
    $LogicalDisk1                          = New-OVServerProfileLogicalDisk  -Name $ldName -Bootable $bootable -RAID $raidLevel -DriveType $driveType -NumberofDrives $numberofDrives  -Accelerator $accelerator 
    $logicalDisks                          = @($LogicalDisk1)
    $controller1                           = New-OVServerProfileLogicalDiskController  -ControllerID "Embedded" -Mode "RAID" -Initialize:$True -WriteCache "Unmanaged"  -LogicalDisk $LogicalDisks 


    $controllers                           = @($controller1)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `
                                     -StorageController $controllers `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "ESXi template for OV4VC demo already exists." 
}


write-host -foreground CYAN "----- Creating profile FW-only Template "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'FW-only Template' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile FC bottom 
    $name                                  = 'FW-only Template'
    $description                           = 'SPT for applying firmware'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "None"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -manageConnections $manageConnections -ConnectionsConsistencyChecking $connectionsConsistency `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "FW-only Template already exists." 
}


write-host -foreground CYAN "----- Creating profile NotWorkingTemplate "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'NotWorkingTemplate' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile FC bottom 
    $name                                  = 'NotWorkingTemplate'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"


    # -------------- Boot mode section 
    $bootMode                              = "UEFI"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -manageConnections $manageConnections -ConnectionsConsistencyChecking $connectionsConsistency `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "NotWorkingTemplate already exists." 
}


write-host -foreground CYAN "----- Creating profile openstack-controller "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'openstack-controller' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile FC bottom 
    $name                                  = 'openstack-controller'
    $description                           = 'Created by ricardo.araujo-santos@hpe.com'
    $spDescription                         = 'OpenStack all-in-one deployment'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "external"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'OpenStack' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'OpenStack' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "OpenStack"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2)


    # -------------- Boot mode section 
    $bootMode                              = "BIOS"
    $bootOrder                             = @('CD','USB','HardDisk','PXE')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerProfileDescription $spDescription -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "openstack-controller already exists." 
}


write-host -foreground CYAN "----- Creating profile openstack-node-flat "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'openstack-node-flat' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile OpenStack 
    $name                                  = 'openstack-node-flat'
    $description                           = 'Created by ricardo.araujo-santos@hpe.com'
    $spDescription                         = 'SH to provide using OpenStack Ironic'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'openstack_200' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'openstack_200' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "flat_connection"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1)


    # -------------- Boot mode section 
    $bootMode                              = "BIOS"
    $bootOrder                             = @('HardDisk','PXE','CD','USB')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerProfileDescription $spDescription -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "openstack-node-flat already exists." 
}


write-host -foreground CYAN "----- Creating profile openstack-node-i3s "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'openstack-node-i3s' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile flat_connection 
    $name                                  = 'openstack-node-i3s'
    $description                           = 'Created by ricardo.araujo-santos@hpe.com'
    $spDescription                         = 'SH to provide using OpenStack Ironic'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'openstack_200' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'openstack_200' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "flat_connection"  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerProfileDescription $spDescription -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "openstack-node-i3s already exists." 
}


write-host -foreground CYAN "----- Creating profile SAS-template "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'SAS-template' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile flat_connection 
    $name                                  = 'SAS-template'
    $description                           = 'check for SAS attributes'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen10 1'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "None"


    # -------------- Local Storage section 
    $lsConsistencyChecking                 = "None"


    # --- Search for SAS-Logical-Interconnect for SASlogicalJBOD 
    $ligAssociation                        = Search-OVAssociations ENCLOSURE_GROUP_TO_LOGICAL_INTERCONNECT_GROUP -parent $eg
    $sasLigUri                             = ($ligAssociation | where ChildUri -like "*sas*").ChildUri
    $sasLig                                = if ($sasLigUri) { Send-OVRequest -uri $sasLigUri } else {$Null}
    $sasUri                                = (Search-OVAssociations LOGICAL_INTERCONNECT_GROUP_TO_LOGICAL_INTERCONNECT -Parent $sasLig).childUri[0]
    $sasLI                                 = if ($sasUri) { Send-OVRequest -uri $sasUri } else {$Null}
    $lsJBOD                                = [System.Collections.ArrayList]::new()
    $controller1                           = New-OVServerProfileLogicalDiskController  -ControllerID "Mezz 1" -Mode "Mixed" -Initialize:$True -WriteCache "Unmanaged" 


    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod1                         = new-OVLogicalJBOD -InputObject $sasLI  -name LD1 -driveType Sas -MinDriveSize 1200 -MaxDriveSize 1200 -EraseDataOneDelete $True  
            if ($jbod1)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 1
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = LD1
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 1200
                $_jbod.driveMaxSizeGB      = 1200
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = True
                $_jbod.sasLogicalJBODUri   = $jbod1.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    $controllers                           = @($controller1)


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -manageConnections $manageConnections -ConnectionsConsistencyChecking $connectionsConsistency `
                                     -StorageController $controllers `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "SAS-template already exists." 
}


write-host -foreground CYAN "----- Creating profile SLES 12 SUSECON "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'SLES 12 SUSECON' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile flat_connection 
    $name                                  = 'SLES 12 SUSECON'
    $description                           = 'Vincent'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Management A"  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "Management B"  -ConnectionID 4 `
                                              -PortId "Mezz 3:2-c" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "SLES 12 SUSECON already exists." 
}


write-host -foreground CYAN "----- Creating profile SLES SPT BF "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'SLES SPT BF' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile Management B 
    $name                                  = 'SLES SPT BF'
    $description                           = 'Bob Fraser'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -manageConnections $manageConnections -ConnectionsConsistencyChecking $connectionsConsistency `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "SLES SPT BF already exists." 
}


write-host -foreground CYAN "----- Creating profile SLES-CEPH-OSD-300GB "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'SLES-CEPH-OSD-300GB' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile Management B 
    $name                                  = 'SLES-CEPH-OSD-300GB'
    $description                           = 'SLES-CEPH-OSD Node'
    $spDescription                         = 'SLES-CEPH-OSD'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen10 1'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "1"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'NCS OSDClient' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'NCS OSDClient' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "2"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'NCS OSDCluster' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'NCS OSDCluster' 
    } # 
    $conn3   = New-OVServerProfileConnection  -name "3"  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'NCS OSDInternal' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'NCS OSDInternal' 
    } # 
    $conn4   = New-OVServerProfileConnection  -name "4"  -ConnectionID 4 `
                                              -PortId "Mezz 3:2-c" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2,$conn3,$conn4)


    # -------------- Local Storage section 
    $lsConsistencyChecking                 = "Exact"


    # --- Search for SAS-Logical-Interconnect for SASlogicalJBOD 
    $ligAssociation                        = Search-OVAssociations ENCLOSURE_GROUP_TO_LOGICAL_INTERCONNECT_GROUP -parent $eg
    $sasLigUri                             = ($ligAssociation | where ChildUri -like "*sas*").ChildUri
    $sasLig                                = if ($sasLigUri) { Send-OVRequest -uri $sasLigUri } else {$Null}
    $sasUri                                = (Search-OVAssociations LOGICAL_INTERCONNECT_GROUP_TO_LOGICAL_INTERCONNECT -Parent $sasLig).childUri[0]
    $sasLI                                 = if ($sasUri) { Send-OVRequest -uri $sasUri } else {$Null}
    $lsJBOD                                = [System.Collections.ArrayList]::new()
    $controller1                           = New-OVServerProfileLogicalDiskController  -ControllerID "Mezz 1" -Mode "Mixed" -Initialize:$True -WriteCache "Unmanaged" 


    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod1                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD8 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod1)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 9
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD8
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod1.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod2                         = new-OVLogicalJBOD -InputObject $sasLI  -name Boot-OS -driveType SasSsd -MinDriveSize 400 -MaxDriveSize 400 -EraseDataOneDelete $True  
            if ($jbod2)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 1
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = Boot-OS
                $_jbod.numPhysicalDrives   = 2
                $_jbod.driveMinSizeGB      = 400
                $_jbod.driveMaxSizeGB      = 400
                $_jbod.driveTechnology     = SasSsd
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod2.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod3                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD1 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod3)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 2
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD1
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod3.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod4                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD6 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod4)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 7
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD6
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod4.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod5                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD7 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod5)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 8
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD7
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod5.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod6                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD4 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod6)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 5
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD4
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod6.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod7                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD5 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod7)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 6
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD5
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod7.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod8                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD2 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod8)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 3
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD2
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod8.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod9                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD3 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod9)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 4
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD3
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod9.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    $controllers                           = @($controller1)


    # -------------- Boot mode section 
    $bootMode                              = "UEFI"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerProfileDescription $spDescription -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `
                                     -StorageController $controllers `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "SLES-CEPH-OSD-300GB already exists." 
}


write-host -foreground CYAN "----- Creating profile SLES-CEPH-OSD-MON-1.2TB "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'SLES-CEPH-OSD-MON-1.2TB' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile 4 
    $name                                  = 'SLES-CEPH-OSD-MON-1.2TB'
    $description                           = 'SLES-CEPH-OSD Node'
    $spDescription                         = 'SLES-CEPH-OSD'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen10 1'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "1"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'NCS OSDClient' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'NCS OSDClient' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "2"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'NCS OSDCluster' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'NCS OSDCluster' 
    } # 
    $conn3   = New-OVServerProfileConnection  -name "3"  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'NCS OSDInternal' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'NCS OSDInternal' 
    } # 
    $conn4   = New-OVServerProfileConnection  -name "4"  -ConnectionID 4 `
                                              -PortId "Mezz 3:2-c" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2,$conn3,$conn4)


    # -------------- Local Storage section 
    $lsConsistencyChecking                 = "Exact"


    # --- Search for SAS-Logical-Interconnect for SASlogicalJBOD 
    $ligAssociation                        = Search-OVAssociations ENCLOSURE_GROUP_TO_LOGICAL_INTERCONNECT_GROUP -parent $eg
    $sasLigUri                             = ($ligAssociation | where ChildUri -like "*sas*").ChildUri
    $sasLig                                = if ($sasLigUri) { Send-OVRequest -uri $sasLigUri } else {$Null}
    $sasUri                                = (Search-OVAssociations LOGICAL_INTERCONNECT_GROUP_TO_LOGICAL_INTERCONNECT -Parent $sasLig).childUri[0]
    $sasLI                                 = if ($sasUri) { Send-OVRequest -uri $sasUri } else {$Null}
    $lsJBOD                                = [System.Collections.ArrayList]::new()
    $controller1                           = New-OVServerProfileLogicalDiskController  -ControllerID "Mezz 1" -Mode "Mixed" -Initialize:$True -WriteCache "Unmanaged" 


    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod1                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD2 -driveType Sas -MinDriveSize 1200 -MaxDriveSize 1200 -EraseDataOneDelete $True  
            if ($jbod1)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 3
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD2
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 1200
                $_jbod.driveMaxSizeGB      = 1200
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod1.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod2                         = new-OVLogicalJBOD -InputObject $sasLI  -name Boot-OS -driveType SasSsd -MinDriveSize 400 -MaxDriveSize 400 -EraseDataOneDelete $True  
            if ($jbod2)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 1
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = Boot-OS
                $_jbod.numPhysicalDrives   = 2
                $_jbod.driveMinSizeGB      = 400
                $_jbod.driveMaxSizeGB      = 400
                $_jbod.driveTechnology     = SasSsd
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod2.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod3                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD3 -driveType Sas -MinDriveSize 1200 -MaxDriveSize 1200 -EraseDataOneDelete $True  
            if ($jbod3)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 4
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD3
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 1200
                $_jbod.driveMaxSizeGB      = 1200
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod3.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod4                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD4 -driveType Sas -MinDriveSize 1200 -MaxDriveSize 1200 -EraseDataOneDelete $True  
            if ($jbod4)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 5
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD4
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 1200
                $_jbod.driveMaxSizeGB      = 1200
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod4.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod5                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD5 -driveType Sas -MinDriveSize 1200 -MaxDriveSize 1200 -EraseDataOneDelete $True  
            if ($jbod5)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 6
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD5
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 1200
                $_jbod.driveMaxSizeGB      = 1200
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod5.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod6                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD-MON -driveType SasSsd -MinDriveSize 400 -MaxDriveSize 400 -EraseDataOneDelete $True  
            if ($jbod6)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 10
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD-MON
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 400
                $_jbod.driveMaxSizeGB      = 400
                $_jbod.driveTechnology     = SasSsd
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod6.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod7                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD6 -driveType Sas -MinDriveSize 1200 -MaxDriveSize 1200 -EraseDataOneDelete $True  
            if ($jbod7)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 7
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD6
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 1200
                $_jbod.driveMaxSizeGB      = 1200
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod7.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod8                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD7 -driveType Sas -MinDriveSize 1200 -MaxDriveSize 1200 -EraseDataOneDelete $True  
            if ($jbod8)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 8
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD7
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 1200
                $_jbod.driveMaxSizeGB      = 1200
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod8.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod9                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD8 -driveType Sas -MinDriveSize 1200 -MaxDriveSize 1200 -EraseDataOneDelete $True  
            if ($jbod9)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 9
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD8
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 1200
                $_jbod.driveMaxSizeGB      = 1200
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod9.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod10                        = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD1 -driveType Sas -MinDriveSize 1200 -MaxDriveSize 1200 -EraseDataOneDelete $True  
            if ($jbod10)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 2
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD1
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 1200
                $_jbod.driveMaxSizeGB      = 1200
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod10.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    $controllers                           = @($controller1)


    # -------------- Boot mode section 
    $bootMode                              = "UEFI"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerProfileDescription $spDescription -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `
                                     -StorageController $controllers `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "SLES-CEPH-OSD-MON-1.2TB already exists." 
}


write-host -foreground CYAN "----- Creating profile SLES-CEPH-OSD-MON-300GB "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'SLES-CEPH-OSD-MON-300GB' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile 4 
    $name                                  = 'SLES-CEPH-OSD-MON-300GB'
    $description                           = 'SLES-CEPH-OSD Node'
    $spDescription                         = 'SLES-CEPH-OSD-MON'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen10 1'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "1"  -ConnectionID 1 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'NCS OSDClient' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'NCS OSDClient' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "2"  -ConnectionID 2 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'NCS OSDCluster' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'NCS OSDCluster' 
    } # 
    $conn3   = New-OVServerProfileConnection  -name "3"  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'NCS OSDInternal' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'NCS OSDInternal' 
    } # 
    $conn4   = New-OVServerProfileConnection  -name "4"  -ConnectionID 4 `
                                              -PortId "Mezz 3:2-c" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2,$conn3,$conn4)


    # -------------- Local Storage section 
    $lsConsistencyChecking                 = "Exact"


    # --- Search for SAS-Logical-Interconnect for SASlogicalJBOD 
    $ligAssociation                        = Search-OVAssociations ENCLOSURE_GROUP_TO_LOGICAL_INTERCONNECT_GROUP -parent $eg
    $sasLigUri                             = ($ligAssociation | where ChildUri -like "*sas*").ChildUri
    $sasLig                                = if ($sasLigUri) { Send-OVRequest -uri $sasLigUri } else {$Null}
    $sasUri                                = (Search-OVAssociations LOGICAL_INTERCONNECT_GROUP_TO_LOGICAL_INTERCONNECT -Parent $sasLig).childUri[0]
    $sasLI                                 = if ($sasUri) { Send-OVRequest -uri $sasUri } else {$Null}
    $lsJBOD                                = [System.Collections.ArrayList]::new()
    $controller1                           = New-OVServerProfileLogicalDiskController  -ControllerID "Mezz 1" -Mode "Mixed" -Initialize:$True -WriteCache "Unmanaged" 


    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod1                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD8 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod1)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 9
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD8
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod1.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod2                         = new-OVLogicalJBOD -InputObject $sasLI  -name Boot-OS -driveType SasSsd -MinDriveSize 400 -MaxDriveSize 400 -EraseDataOneDelete $True  
            if ($jbod2)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 1
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = Boot-OS
                $_jbod.numPhysicalDrives   = 2
                $_jbod.driveMinSizeGB      = 400
                $_jbod.driveMaxSizeGB      = 400
                $_jbod.driveTechnology     = SasSsd
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod2.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod3                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD1 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod3)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 2
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD1
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod3.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod4                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD6 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod4)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 7
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD6
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod4.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod5                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD7 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod5)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 8
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD7
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod5.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod6                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD-MON -driveType SasSsd -MinDriveSize 400 -MaxDriveSize 400 -EraseDataOneDelete $True  
            if ($jbod6)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 10
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD-MON
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 400
                $_jbod.driveMaxSizeGB      = 400
                $_jbod.driveTechnology     = SasSsd
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod6.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod7                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD4 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod7)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 5
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD4
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod7.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod8                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD5 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod8)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 6
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD5
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod8.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod9                         = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD2 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod9)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 3
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD2
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod9.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    if ($sasLI)			# If SAS logical Interconnect exists
    {
        $availableDrives                   = Get-OVAvailableDriveType -InputObject $sasLI | where { $_.Capacity -eq $MaxDriveSize -and $_.Type -eq $DriveTechnology -and $_.NumberAvailable -eq $numPhysicalDrives}
        if ($availableDrives)		# if there are such drives in SAS
        {
            $jbod10                        = new-OVLogicalJBOD -InputObject $sasLI  -name JBOD3 -driveType Sas -MinDriveSize 300 -MaxDriveSize 300 -EraseDataOneDelete $True  
            if ($jbod10)
            {
                $_jbod                     = new-object -type sasJBOD
                $_jbod.id                  = 4
                $_jbod.deviceSlot          = Mezz 1
                $_jbod.name                = JBOD3
                $_jbod.numPhysicalDrives   = 1
                $_jbod.driveMinSizeGB      = 300
                $_jbod.driveMaxSizeGB      = 300
                $_jbod.driveTechnology     = Sas
                $_jbod.eraseData           = True
                $_jbod.persistent          = False
                $_jbod.sasLogicalJBODUri   = $jbod10.uri
                [void]$lsJBOD.Add($_jbod)
            } # 
        } # 
    } # 
    $controllers                           = @($controller1)


    # -------------- Boot mode section 
    $bootMode                              = "UEFI"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerProfileDescription $spDescription -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `
                                     -StorageController $controllers `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "SLES-CEPH-OSD-MON-300GB already exists." 
}


write-host -foreground CYAN "----- Creating profile SPP 2017.07 "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'SPP 2017.07' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile 4 
    $name                                  = 'SPP 2017.07'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -manageConnections $manageConnections -ConnectionsConsistencyChecking $connectionsConsistency `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "SPP 2017.07 already exists." 
}


write-host -foreground CYAN "----- Creating profile SUSE "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'SUSE' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile 4 
    $name                                  = 'SUSE'
    $description                           = 'Vincent'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Management A"  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-a" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "Management B"  -ConnectionID 4 `
                                              -PortId "Mezz 3:2-a" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -description $description -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "SUSE already exists." 
}


write-host -foreground CYAN "----- Creating profile Template for OV4VC Image Streamer "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'Template for OV4VC Image Streamer' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile Management B 
    $name                                  = 'Template for OV4VC Image Streamer'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen9 2'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 
    $manageConnections                     = $True
    $connectionsConsistency                = "Exact"
    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn1   = New-OVServerProfileConnection  -name "Management A"  -ConnectionID 3 `
                                              -PortId "Mezz 3:1-c" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'Management' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'Management' 
    } # 
    $conn2   = New-OVServerProfileConnection  -name "Management B"  -ConnectionID 4 `
                                              -PortId "Mezz 3:2-c" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'FC Discover top' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'FC Discover top' 
    } # 
    $conn3   = New-OVServerProfileConnection  -name "FC top"  -ConnectionID 5 `
                                              -PortId "Mezz 3:1-b" -RequestedBW 2500 `
                                              -network $network   


    $network                               = Get-OVnetwork | where name -eq 'FC Discover bottom' 
    if ($null -eq $network)
    {
        $network                           = Get-OVnetworkSet | where name -eq 'FC Discover bottom' 
    } # 
    $conn4   = New-OVServerProfileConnection  -name "FC bottom"  -ConnectionID 6 `
                                              -PortId "Mezz 3:2-b" -RequestedBW 2500 `
                                              -network $network   


    $connectionList                        = @($conn1,$conn2,$conn3,$conn4)


    # -------------- Local Storage section 
    $lsConsistencyChecking                 = "None"


    # --- Search for SAS-Logical-Interconnect for SASlogicalJBOD 
    $ligAssociation                        = Search-OVAssociations ENCLOSURE_GROUP_TO_LOGICAL_INTERCONNECT_GROUP -parent $eg
    $sasLigUri                             = ($ligAssociation | where ChildUri -like "*sas*").ChildUri
    $sasLig                                = if ($sasLigUri) { Send-OVRequest -uri $sasLigUri } else {$Null}
    $sasUri                                = (Search-OVAssociations LOGICAL_INTERCONNECT_GROUP_TO_LOGICAL_INTERCONNECT -Parent $sasLig).childUri[0]
    $sasLI                                 = if ($sasUri) { Send-OVRequest -uri $sasUri } else {$Null}
    $lsJBOD                                = [System.Collections.ArrayList]::new()
    $controller1                           = New-OVServerProfileLogicalDiskController  -ControllerID "Embedded" -Mode "HBA" -Initialize:$True -WriteCache "Unmanaged" 


    $controllers                           = @($controller1)


    # -------------- Boot mode section 
    $bootMode                              = "UEFIOptimized"
    $bootOrder                             = @('HardDisk')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Connections $connectionList  `
                                     -StorageController $controllers `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "Template for OV4VC Image Streamer already exists." 
}


write-host -foreground CYAN "----- Creating profile UEFI Boot Template "
$profile                                   = get-OVServerProfileTemplate | where name -eq  'UEFI Boot Template' 
if ($Null -eq $profile )
{
    # -------------- Attributes for profile FC bottom 
    $name                                  = 'UEFI Boot Template'
    $sht                                   = Get-OVserverHardwareType -name 'SY 480 Gen10 1'
    $eg                                    = Get-OVEnclosureGroup -name 'EG 3 frames'
    $affinity                              = 'Bay'


    # -------------- Connections section 


    # -------------- Boot mode section 
    $bootMode                              = "UEFI"
    $bootOrder                             = @('PXE')
    $bmConsistency                         = "Exact"
    $boConsistency                         = "Exact"


    # -------------- BIOS section 
    $biosSettings                          = @(
        @{ id = "Ipv4Gateway"; value = "192.168.101.1"},
        @{ id = "Ipv4SubnetMask"; value = "255.255.255.0"},
        @{ id = "Dhcpv4"; value = "Disabled"},
        @{ id = "Ipv4PrimaryDNS"; value = "192.168.101.1"},
        @{ id = "Ipv4Address"; value = "192.168.101.215"},
        @{ id = "UrlBootFile"; value = "http://192.168.101.23/isos/rhel7.6.iso"}
        )
    $biosConsistency                       = "Exact"


    new-OVServerProfileTemplate	 	 -Name $name  -ServerHardwareType $sht -EnclosureGroup $eg -affinity $affinity `
                                     -bootMode $bootMode  -PxeBootPolicy Auto -BootModeConsistencyChecking $bmConsistency `
                                     -ManageBoot $True -BootOrder $bootOrder -BootOrderConsistencyChecking $boConsistency `
                                     -Bios -BiosSettings $biosSettings -BiosConsistencyChecking $biosConsistency `


    if ($lsJBOD)
    {
        # ------ Configure saslogicalJBOD for profile
        $prf                               = get-OVServerProfileTemplate | where name -eq $name
        if ($prf)
        {
            $lsJBOD | % { $prf.localStorage.sasLogicalJBODs += $_ }
        } # 
        save-OVServerProfileTemplate -InputObject $prf
    } # 
} # 
else
{
    write-host -foreground YELLOW "UEFI Boot Template already exists." 
}


Disconnect-OVMgmt
