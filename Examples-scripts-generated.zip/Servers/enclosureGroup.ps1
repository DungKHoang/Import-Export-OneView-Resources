﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


write-host -foreground CYAN "----- Creating enclosure Group PYTHON6666-dung-EG "
$eg                                        = get-OVEnclosureGroup | where name -eq  'PYTHON6666-dung-EG' 
if ($Null -eq $eg)
{
    # -------------- Attributes for enclosure group PYTHON6666-dung-EG 
    $name                                  = "PYTHON6666-dung-EG"
    $enclosureCount                        = 3
    $ipV4AddressType                       = "AddressPool"
    $IPv4AddressRange                      = @('Deployment') | % {Get-OVAddressPoolRange | where name -eq $_ } 
    $ipV6AddressType                       = "External"
    $powerMode                             = "RedundantPowerFeed"
    $lig1                                  = Get-OVLogicalInterconnectGroup -name 'LIG-SAS'
    $lig2                                  = Get-OVLogicalInterconnectGroup -name 'LIG-VC3'
    $lig3                                  = Get-OVLogicalInterconnectGroup -name 'OBT-LIG-FC2-5'
    $ligGroupMapping                       = @{Frame1=$lig2,$lig1,$lig3;Frame2=$lig2,$lig1;Frame3=$lig2,$lig3}


    New-OVEnclosureGroup	-Name $name -enclosureCount $enclosureCount  -IPv4AddressType $ipV4AddressType -IPv4AddressRange $IPv4AddressRange -IPv6AddressType $ipV6AddressType `
                         -LogicalInterconnectGroupMapping $ligGroupMapping -PowerRedundantMode $powerMode `
                         -DeploymentNetworkType Internal  `


} # 
else
{
    write-host -foreground YELLOW PYTHON6666-dung-EG already exists.
}


write-host -foreground CYAN "----- Creating enclosure Group EG 3 frames "
$eg                                        = get-OVEnclosureGroup | where name -eq  'EG 3 frames' 
if ($Null -eq $eg)
{
    # -------------- Attributes for enclosure group EG 3 frames 
    $name                                  = "EG 3 frames"
    $enclosureCount                        = 3
    $ipV4AddressType                       = "DHCP"
    $ipV6AddressType                       = "External"
    $powerMode                             = "RedundantPowerFeed"
    $lig1                                  = Get-OVLogicalInterconnectGroup -name 'LIG-SAS'
    $lig2                                  = Get-OVLogicalInterconnectGroup -name 'LIG-VC3'
    $ligGroupMapping                       = @{Frame1=$lig2,$lig1;Frame2=$lig2;Frame3=$lig2,$lig1}


    New-OVEnclosureGroup	-Name $name -enclosureCount $enclosureCount  -IPv4AddressType $ipV4AddressType -IPv6AddressType $ipV6AddressType `
                         -LogicalInterconnectGroupMapping $ligGroupMapping -PowerRedundantMode $powerMode `
                         -DeploymentNetworkType Internal  `


} # 
else
{
    write-host -foreground YELLOW EG 3 frames already exists.
}


Disconnect-OVMgmt
