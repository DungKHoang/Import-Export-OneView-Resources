﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


write-host -foreground CYAN '----- Creating snmp trap $trap1 '
$trap1                                     = New-OVApplianceTrapDestination  -Type SnmpV1  -Destination "192.168.1.123"  -Port 162  -Community public 


$snmpV3user                                = Get-OVSnmpV3User | where UserName -eq "snmp_user" 
write-host -foreground CYAN '----- Creating snmp trap $trap2 '
$trap2                                     = New-OVApplianceTrapDestination  -Type SnmpV3  -Destination "192.168.1.67"  -Port 162  -SnmpV3user $snmpV3user 


$snmpV3user                                = Get-OVSnmpV3User | where UserName -eq "snmp_user" 
write-host -foreground CYAN '----- Creating snmp trap $trap3 '
$trap3                                     = New-OVApplianceTrapDestination  -Type SnmpV3  -Destination "192.168.3.245"  -Port 162  -SnmpV3user $snmpV3user 




Disconnect-OVMgmt
