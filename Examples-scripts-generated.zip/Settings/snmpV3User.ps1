﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 





write-host -foreground CYAN "----- Creating snmpV3 user snmp_user " 
if ($null -eq (Get-OVSnmpV3User | where name -eq "snmp_user"))
{
    $authPassword                          = "***REDACTED***" | ConvertTo-SecureString -AsPlainText -Force
    $snmpv3User1                           = new-OVSnmpV3User  -ApplianceSnmpUser  -UserName "snmp_user"  -SecurityLevel "AuthOnly" -AuthProtocol "sha512" -AuthPassword $authPassword
}
else
{
    write-host -foreground YELLOW 'snmp_user' already exists.
}


    write-host -foreground CYAN "----- Creating snmpV3 user snmp_userAuthPriv " 
    if ($null -eq (Get-OVSnmpV3User | where name -eq "snmp_userAuthPriv"))
{
        $authPassword                      = "***REDACTED***" | ConvertTo-SecureString -AsPlainText -Force
        $privPassword                      = "***REDACTED***" | ConvertTo-SecureString -AsPlainText -Force
        $snmpv3User2                       = new-OVSnmpV3User  -ApplianceSnmpUser  -UserName "snmp_userAuthPriv"  -SecurityLevel "AuthAndPriv" -AuthProtocol "sha512" -AuthPassword $authPassword -PrivProtocol "aes256" -PrivPassword $privPassword
}
else
{
        write-host -foreground YELLOW 'snmp_userAuthPriv' already exists.
}


Disconnect-OVMgmt
