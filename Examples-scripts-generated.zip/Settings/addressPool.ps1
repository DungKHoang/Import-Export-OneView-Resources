﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 



write-host -foreground CYAN "----- Creating address pools VMAC "
    # -------------- Attributes for address Pools "VMAC"
$proceed                                   = $False
$poolType                                  = "VMAC"
$rangeType                                 = "Generated"
$startAddress                              = "0E:CC:2A:E0:00:00"
$endAddress                                = "0E:CC:2A:EF:FF:FF"
$deleteGenerated                           = $False
$addressPool                               = Get-OVAddressPoolRange| where {($_.name -eq $poolType) -and ($_.rangeCategory -eq $rangeType)} 
$proceed                                   = $null -eq ($addressPool | where startAddress -eq $startAddress)
$poolToDelete                              = Get-OVAddressPoolRange| where {($_.name -eq $poolType) -and ($_.rangeCategory -eq "Generated")} 
$poolToDelete |  Remove-OVAddressPoolRange -confirm:$False
if ($proceed)
{
    New-OVAddressPoolRange -PoolType $poolType -RangeType $rangeType  
} # 
else
{
        write-host -foreground YELLOW 'VMAC' already exists.
}


write-host -foreground CYAN "----- Creating address pools VMAC "
    # -------------- Attributes for address Pools "VMAC"
$proceed                                   = $False
$poolType                                  = "VMAC"
$rangeType                                 = "Generated"
$startAddress                              = "C6:97:ED:90:00:00"
$endAddress                                = "C6:97:ED:9F:FF:FF"
$deleteGenerated                           = $False
$addressPool                               = Get-OVAddressPoolRange| where {($_.name -eq $poolType) -and ($_.rangeCategory -eq $rangeType)} 
$proceed                                   = $null -eq ($addressPool | where startAddress -eq $startAddress)
$poolToDelete                              = Get-OVAddressPoolRange| where {($_.name -eq $poolType) -and ($_.rangeCategory -eq "Generated")} 
$poolToDelete |  Remove-OVAddressPoolRange -confirm:$False
if ($proceed)
{
    New-OVAddressPoolRange -PoolType $poolType -RangeType $rangeType  
} # 
else
{
        write-host -foreground YELLOW 'VMAC' already exists.
}


write-host -foreground CYAN "----- Creating address pools VWWN "
    # -------------- Attributes for address Pools "VWWN"
$proceed                                   = $False
$poolType                                  = "VWWN"
$rangeType                                 = "Generated"
$startAddress                              = "10:00:ea:e3:4b:70:00:00"
$endAddress                                = "10:00:ea:e3:4b:7f:ff:ff"
$deleteGenerated                           = $False
$addressPool                               = Get-OVAddressPoolRange| where {($_.name -eq $poolType) -and ($_.rangeCategory -eq $rangeType)} 
$proceed                                   = $null -eq ($addressPool | where startAddress -eq $startAddress)
$poolToDelete                              = Get-OVAddressPoolRange| where {($_.name -eq $poolType) -and ($_.rangeCategory -eq "Generated")} 
$poolToDelete |  Remove-OVAddressPoolRange -confirm:$False
if ($proceed)
{
    New-OVAddressPoolRange -PoolType $poolType -RangeType $rangeType  
} # 
else
{
        write-host -foreground YELLOW 'VWWN' already exists.
}


write-host -foreground CYAN "----- Creating address pools VSN "
    # -------------- Attributes for address Pools "VSN"
$proceed                                   = $False
$poolType                                  = "VSN"
$rangeType                                 = "Generated"
$startAddress                              = "VCGSDBV000"
$endAddress                                = "VCGSDBVZZZ"
$deleteGenerated                           = $False
$addressPool                               = Get-OVAddressPoolRange| where {($_.name -eq $poolType) -and ($_.rangeCategory -eq $rangeType)} 
$proceed                                   = $null -eq ($addressPool | where startAddress -eq $startAddress)
$poolToDelete                              = Get-OVAddressPoolRange| where {($_.name -eq $poolType) -and ($_.rangeCategory -eq "Generated")} 
$poolToDelete |  Remove-OVAddressPoolRange -confirm:$False
if ($proceed)
{
    New-OVAddressPoolRange -PoolType $poolType -RangeType $rangeType  
} # 
else
{
        write-host -foreground YELLOW 'VSN' already exists.
}


write-host -foreground CYAN "----- Creating address pools VSN "
    # -------------- Attributes for address Pools "VSN"
$proceed                                   = $False
$poolType                                  = "VSN"
$rangeType                                 = "Generated"
$startAddress                              = "VCG3OBS000"
$endAddress                                = "VCG3OBSZZZ"
$deleteGenerated                           = $False
$addressPool                               = Get-OVAddressPoolRange| where {($_.name -eq $poolType) -and ($_.rangeCategory -eq $rangeType)} 
$proceed                                   = $null -eq ($addressPool | where startAddress -eq $startAddress)
$poolToDelete                              = Get-OVAddressPoolRange| where {($_.name -eq $poolType) -and ($_.rangeCategory -eq "Generated")} 
$poolToDelete |  Remove-OVAddressPoolRange -confirm:$False
if ($proceed)
{
    New-OVAddressPoolRange -PoolType $poolType -RangeType $rangeType  
} # 
else
{
        write-host -foreground YELLOW 'VSN' already exists.
}


write-host -foreground CYAN "----- Creating address pools Image Streamer "
    # -------------- Attributes for address Pools "Image Streamer"
$proceed                                   = $False
$poolType                                  = "ipv4"
$rangeType                                 = "Custom"
$startAddress                              = "192.168.2.21"
$endAddress                                = "192.168.2.50"
$deleteGenerated                           = $False
$name                                      = "Image Streamer"
$networkId                                 = "192.168.0.0"
$subnetmask                                = "255.255.252.0"
$gateway                                   = "192.168.1.11"
$dnsServers                                = @('192.168.1.1','16.31.84.24')
if ($poolType -like "ip*")
{
    $subnet                                =  Get-OVAddressPoolSubnet | where networkId -eq '192.168.0.0'
    if ($subnet -ne $null) 
    {
        $addressPool                       = Get-OVAddressPoolRange | where subnetUri -match ($subnet.uri)
        $proceed                           = $null -eq ($addressPool.startStopFragments.startAddress -ne $startAddress)
    } # $subnet....
    else
    {
        $subnet                            = new-OVAddressPoolSubnet -NetworkId $networkId -SubnetMask $subnetMask -Gateway $gateway  -DNSServers $dnsServers 
        $proceed                           = $True
    }
} # $poolType....
if ($proceed)
{
    New-OVAddressPoolRange -IPSubnet $subnet -name "Image Streamer"  -Start $startAddress -End $endAddress 
} # 
else
{
        write-host -foreground YELLOW 'Image Streamer' already exists.
}


write-host -foreground CYAN "----- Creating address pools Deployment "
    # -------------- Attributes for address Pools "Deployment"
$proceed                                   = $False
$poolType                                  = "ipv4"
$rangeType                                 = "Custom"
$startAddress                              = "192.168.8.50"
$endAddress                                = "192.168.8.200"
$deleteGenerated                           = $False
$name                                      = "Deployment"
$networkId                                 = "192.168.8.0"
$subnetmask                                = "255.255.255.0"
$gateway                                   = "192.168.8.1"
if ($poolType -like "ip*")
{
    $subnet                                =  Get-OVAddressPoolSubnet | where networkId -eq '192.168.8.0'
    if ($subnet -ne $null) 
    {
        $addressPool                       = Get-OVAddressPoolRange | where subnetUri -match ($subnet.uri)
        $proceed                           = $null -eq ($addressPool.startStopFragments.startAddress -ne $startAddress)
    } # $subnet....
    else
    {
        $subnet                            = new-OVAddressPoolSubnet -NetworkId $networkId -SubnetMask $subnetMask -Gateway $gateway 
        $proceed                           = $True
    }
} # $poolType....
if ($proceed)
{
    New-OVAddressPoolRange -IPSubnet $subnet -name "Deployment"  -Start $startAddress -End $endAddress 
} # 
else
{
        write-host -foreground YELLOW 'Deployment' already exists.
}


Disconnect-OVMgmt
