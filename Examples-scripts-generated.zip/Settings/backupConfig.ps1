﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 



$hostSSHKey                                = 'ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBNyklnYiGUB8baHhbPYkTEuvLLTIZfGR+eFO0Zn+CZHw/njtbnoxkrylA6S7Mxt1mVokpGzt7lX9eYIAFC/Oul8='
$securepass                                = '***REDACTED***' | ConvertTo-SecureString -AsPlainText -Force 
Set-OVAutomaticBackupConfig  -Hostname "ovhelper.etss.lab"  -protocol "SFTP" -HostSSHKey $hostSSHKey -Directory "ovbackups"  `
     -Username "vincent" -password $securepass   -Interval "WEEKLY" -Time "00:00"  -Days @('MO')


Disconnect-OVMgmt
