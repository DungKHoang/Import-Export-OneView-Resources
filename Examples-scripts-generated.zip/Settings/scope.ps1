﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 





write-host -foreground CYAN "----- Creating scopes Scope 1 "
$username                                  = 'Scope 1'
if ($null -eq (get-OVScope | where name -eq "Scope 1" ))
{
    New-OVScope -name "Scope 1"  -Description "Marketing department"  


    $resources                             = @()
    $res1                                  = Get-OVF2-CN7515049D, bay 2 | where name -eq 
    if ($res1)
    {
        $resources                         = $resources + $res1
    } # 
if ($resources)
{
        get-OVScope -name "Scope 1" | Add-OVResourceToScope -InputObject $resources 
    } # 


} # $null -eq (get-OVScope....
else
{
    write-host -foreground YELLOW 'Scope 1' already exists.
}


write-host -foreground CYAN "----- Creating scopes Scope 2 "
$username                                  = 'Scope 2'
if ($null -eq (get-OVScope | where name -eq "Scope 2" ))
{
    New-OVScope -name "Scope 2"  


    $resources                             = @()
    $res1                                  = Get-OVF2-CN7515049D, bay 2 | where name -eq 
    if ($res1)
    {
        $resources                         = $resources + $res1
    } # 
if ($resources)
{
        get-OVScope -name "Scope 2" | Add-OVResourceToScope -InputObject $resources 
    } # 


} # $null -eq (get-OVScope....
else
{
    write-host -foreground YELLOW 'Scope 2' already exists.
}
Disconnect-OVMgmt
