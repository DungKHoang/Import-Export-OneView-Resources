﻿Param ($ovIP, $maxStudent)

function import-ethernetwork( [string]$netName, [string]$netVLAN)
{
    $newNet                                    = $Null
    write-host -foreground CYAN "----- Creating ethernet networks $netName "
    $net                                       = get-OVNetwork | where name -eq $netName
    if ($Null -eq $net )
    {
        # -------------- Attributes for Ethernet network "ch_oam_3"
        $name                                  = $netName 
        $vLANType                              = "Tagged"
        $vLANid                                = $netVLAN
        $pBandwidth                            = 2500
        $mBandwidth                            = 10000
        $PLAN                                  = $False
        $smartLink                             = $False
        $purpose                               = "General"
        $newNet                                = New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                                                    -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth

        return $newNet

    } # 
    else
    {
        write-host -foreground YELLOW "$netName already exists."
    }
}

function import-fcnetwork( [string]$netName)
{
    write-host -foreground CYAN "----- Creating FC/FCOE networks $netName "
    $net                                       = get-OVNetwork -type FibreChannel | where name -eq $netName
    if ($Null -eq $net )
    {
        # -------------- Attributes for FC network 
        $name                                  = $netName
        $type                                  = "FibreChannel"
        $pBandwidth                            = 2500
        $mBandwidth                            = 20000
        $fabricType                            = "FabricAttach"
        $autologinredistribution               = $False


        New-OVNetwork -Name $netName -Type $Type `
                    -typicalBandwidth $pBandwidth -maximumBandwidth $mBandwidth -FabricType $fabricType -AutoLoginRedistribution $autologinredistribution


    } # 
    else
    {
        write-host -foreground YELLOW $netName already exists.
    }
}

function import-netset([string]$netName, $networkNames)
{
    $networks                = [System.Collections.ArrayList]::new()
    write-host -foreground CYAN "----- Creating networkset $netName "
    $net                                       = get-OVNetworkSet | where name -eq $netName
    if ($Null -eq $net )
    {
        # -------------- Attributes for Network Set 
        $name                                  = $netName
        $pBandwidth                            = 2500
        $mBandwidth                            = 10000
        foreach($_name in $networkNames)
        {
            $_net           = get-OVnetwork -name $_name
            if ($_net)
            {
                [void]$networks.Add($_net)
            }
        }

        if ($networks)
        {
            New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -Networks $networks
        }
        else 
        {
            New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth
        }
    } # 
    else
    {
        write-host -foreground YELLOW "$netName already exists."
    }
}

function import-logicalinterconnectgroup ([string]$ligName, $internalNetwork)
{
    write-host -foreground CYAN "----- Creating logical interconnect group $ligName " 
    $networks                = [System.Collections.ArrayList]::new()
    $lig                                       = get-OVLogicalInterconnectGroup | where name -eq  $ligName
    if ($lig -eq $Null)
    {
        foreach($_name in $internalNetwork)
        {
            $_net           = get-OVnetwork -name $_name
            if ($_net)
            {
                [void]$networks.Add($_net)
            }
        }

        # -------------- Attributes for LIG 
        $name                                  = $ligName
        $frameCount                            = 3
        $interconnectBaySet                    = 3
        $fabricModuleType                      = 'SEVC40f8'
        $redundancyType                        = "HighlyAvailable"
        $bayConfig                             = @{Frame1=@{Bay3='SEVC40f8';Bay6='SE20ILM'};Frame2=@{Bay3='SE20ILM';Bay6='SEVC40f8'};Frame3=@{Bay3='SE20ILM';Bay6='SE20ILM'}}
        $enableNetworkLoopProtection           = $True
        $enableRichTLV                         = $False
        $enableTaggedLldp                      = $False
        $lldpIpAddressMode                     = 'IPV4'
        $interconnectConsistency               = 'Exact'
        $internalNetworks                      = $networks
        $internalNetworkConsistency            = 'Exact'






        $lig = New-OVLogicalInterconnectGroup -Name $name  -fabricModuleType $fabricModuleType -frameCount $frameCount -interConnectBaySet $interConnectBaySet  `
                    -Bays $bayConfig -FabricRedundancy $redundancyType `
                    -InternalNetworks $internalNetworks -internalNetworkConsistencyChecking $internalNetworkConsistency -enablenetworkLoopProtection $enableNetworkLoopProtection `
                    -enableEnhancedLLDPTLV $enableRichTLV `
                    -lldpAddressingMode $lldpIpAddressMode -enableLLDPTagging $enableTaggedLldp -interconnectConsistencyChecking $interconnectConsistency `



    } # if ($lig -eq $Null)
    else
    {
        write-host -foreground YELLOW "$ligName already exists."
    }

}
function import-lig ([string]$ligName, $internalNetwork, $uplName, $networkNames)
{
    write-host -foreground CYAN "----- Creating logical interconnect group $ligName " 
    $networks                = [System.Collections.ArrayList]::new()
    $lig                                       = get-OVLogicalInterconnectGroup | where name -eq  $ligName
    if ($lig -eq $Null)
    {
        foreach($_name in $internalNetwork)
        {
            $_net           = get-OVnetwork -name $_name
            if ($_net)
            {
                [void]$networks.Add($_net)
            }
        } 
        ####
        # -------------- Attributes for Logical Interconnect Group "lig-226"
        $name                               = $ligName
        $frameCount                         = 3
        $bayConfig                          = @{
            Frame1 = @{
                Bay3 = 'SEVC40f8';
                Bay6 = 'SE20ILM'
            };
            Frame2 = @{
                Bay3 = 'SE20ILM';
                Bay6 = 'SEVC40f8'
            };
            Frame3 = @{
                Bay3 = 'SE20ILM';
                Bay6 = 'SE20ILM'
            }
        }
        $redundancyType                     = "HighlyAvailable"
        $fabricModuleType                   = "SEVC40f8"
        $InterconnectBaySet                 = 3
        $networkLoopProtection              = $True
        $InterconnectConsistency            = "Exact"
        $intNetnames                        = $networks
        $InternalNetworkConsistency         = "Exact"
        $lig = New-OVLogicalInterconnectGroup -Name $name -Bays $bayConfig -FabricModuleType $fabricModuleType -fabricredundancy $redundancyType -FrameCount $frameCount -InterConnectBaySet $InterconnectBaySet -InternalNetworks $intNetnames -InternalNetworkConsistencyChecking $InternalNetworkConsistency -enablenetworkLoopProtection:$networkLoopProtection -InterconnectConsistencyChecking $InterconnectConsistency


        # -------------- Attributes for Uplink Set "upl-226" associated to LogicalInterconnectGroup "lig-226"
        $name                               = $uplName
        $uplinkType                         = "Ethernet"
        $parentName                         = $ligName
        $parent                             = Get-OVLogicalInterconnectGroup -Name $parentName
        $uplinkPorts                        = "Enclosure1:Bay3:Q1", "Enclosure2:Bay6:Q1"
        $networks                           = $networkNames | Get-OVNetwork
        $uplConsistency                     = "Exact"
        #$networkSets                        = "netSet-Student226" | % { Get-OVNetworkSet -name $_ }
        $ethMode                            = "Auto"
        $lacpTimer                          = "Short"
        New-OVUplinkSet -InputObject $parent -Name $name -Type $uplinkType -Networks $networks -ConsistencyChecking $uplConsistency -EthMode $ethMode -lacptimer $lacpTimer -UplinkPorts $uplinkPorts


        ####

    } # if ($lig -eq $Null)
    else
    {
        write-host -foreground YELLOW "$ligName already exists."
    }
}
function import-lig1Frame ([string]$ligName, $internalNetwork)
{
    write-host -foreground CYAN "----- Creating logical interconnect group $ligName " 
    $networks                = [System.Collections.ArrayList]::new()
    $lig                                       = get-OVLogicalInterconnectGroup | where name -eq  $ligName
    if ($lig -eq $Null)
    {
        foreach($_name in $internalNetwork)
        {
            $_net           = get-OVnetwork -name $_name
            if ($_net)
            {
                [void]$networks.Add($_net)
            }
        } 
        ####
        # -------------- Attributes for Logical Interconnect Group "lig-226"
        $name                               = $ligName
        $frameCount                         = 1
        $bayConfig                          = @{
            Frame1 = @{
                Bay3 = 'SEVC40f8';
                Bay6 = 'SEVC40f8'
            }
        }
        $redundancyType                     = "Redundant"
        $fabricModuleType                   = "SEVC40f8"
        $InterconnectBaySet                 = 3
        $networkLoopProtection              = $True
        $InterconnectConsistency            = "Exact"
        $intNetnames                        = $networks
        $InternalNetworkConsistency         = "Exact"
        $lig = New-OVLogicalInterconnectGroup -Name $name -Bays $bayConfig -FabricModuleType $fabricModuleType -fabricredundancy $redundancyType -FrameCount $frameCount -InterConnectBaySet $InterconnectBaySet -InternalNetworks $intNetnames -InternalNetworkConsistencyChecking $InternalNetworkConsistency -enablenetworkLoopProtection:$networkLoopProtection -InterconnectConsistencyChecking $InterconnectConsistency

        ####

    } # if ($lig -eq $Null)
    else
    {
        write-host -foreground YELLOW "$ligName already exists."
    }
}
function import-ligfc ([string]$ligName, [string]$upltop, [string]$uplbottom)
{
    write-host -foreground CYAN "----- Creating logical interconnect group $ligName " 
    $lig                                       = get-OVLogicalInterconnectGroup | where name -eq  $ligName
    if ($lig -eq $Null)
    {
        ####
        $name                               = $ligName
        $frameCount                         = 1
        $bayConfig                          = @{
            Frame1 = @{
                Bay2 = 'SEVC32GbFC';
                Bay5 = 'SEVC32GbFC'
            }
        }
        $redundancyType                     = "Redundant"
        $fabricModuleType                   = "SEVCFC"
        $InterconnectBaySet                 = 2
        $networkLoopProtection              = $True
        $InterconnectConsistency            = "Exact"
        $lig = New-OVLogicalInterconnectGroup -Name $name -Bays $bayConfig -FabricModuleType $fabricModuleType -fabricredundancy $redundancyType -FrameCount $frameCount -InterConnectBaySet $InterconnectBaySet -enablenetworkLoopProtection:$networkLoopProtection -InterconnectConsistencyChecking $InterconnectConsistency


        # -------------- Attributes for Uplink Set "upl-fc-A-226" associated to LogicalInterconnectGroup "fc-226"
        $name                               = $upltop
        $uplinkType                         = "FibreChannel"
        $parentName                         = $ligName
        $parent                             = Get-OVLogicalInterconnectGroup -Name $parentName
        $uplinkPorts                        = "Bay2:1", "Bay2:2"
        $uplConsistency                     = "Exact"
        $fcSpeed                            = "Auto"
        $networks                              = $upltop | % { get-OVNetwork -name $_ }
        New-OVUplinkSet -InputObject $parent -Name $name -Type $uplinkType -ConsistencyChecking $uplConsistency -fcUplinkSpeed $FCSpeed -UplinkPorts $uplinkPorts -networks $networks
        # -------------- Attributes for Uplink Set "upl-FC-B-226" associated to LogicalInterconnectGroup "fc-226"
        $name                               = $uplbottom
        $uplinkType                         = "FibreChannel"
        $parentName                         = $ligName
        $parent                             = Get-OVLogicalInterconnectGroup -Name $parentName
        $uplinkPorts                        = "Bay5:1", "Bay5:2"
        $uplConsistency                     = "Exact"
        $fcSpeed                            = "Auto"
        $networks                           = $uplbottom | % { get-OVNetwork -name $_ }
        New-OVUplinkSet -InputObject $parent -Name $name -Type $uplinkType -ConsistencyChecking $uplConsistency -fcUplinkSpeed $FCSpeed -UplinkPorts $uplinkPorts -networks $networks
        ####

    } # if ($lig -eq $Null)
    else
    {
        write-host -foreground YELLOW "$ligName already exists."
    }
}
function import-users([string]$username)
{
    if ($null -eq (get-OVuser -name $username))
    {
        new-OVuser -username $username -password password -roles "Infrastructure administrator"
    }
    else 
    {
        write-host -foreground YELLOW "User $username already exists"
    }
    
}


write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView $ovIP" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname $ovIP -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 

#-------------- Start here

$newNet                 = $Null
foreach ($studentID in 226..$maxStudent)
{
    $netNamesArr               = [System.Collections.ArrayList]::new()
    $multiplier         = $studentID *10
    foreach($i in 0..9)
    {
        $index          = $multiplier + $i
        $netName        = "net-VLAN{0}-Student{1}" -f $index , $studentID.ToString('00') 
        import-ethernetwork -netName $netName -netVLAN $index 
        [void]$netNamesArr.Add($netName)

    }

    $index              = $studentID.ToString('00') 
    $internalNetwork    = "net-VLAN{0}-Student{1}" -f $index  , $index 
    import-ethernetwork -netName $internalNetwork -netVLAN $index
    
 

    $userName              = "student{0}"           -f $studentID.ToString('00') 
    import-users -username $userName

    $netSetName            = "netSet-Student{0}"    -f $studentID.ToString('00') 
    import-netset -netName $netSetName -networkNames $netNamesArr

    $ligName            = "lig-Student{0}" -f $studentID.ToString('00') 
    $uplName            = "upl-Student{0}" -f $studentID.ToString('00') 
    $netNamesArr
    import-lig -ligName $ligName -internalNetwork $internalNetwork -uplName $uplName -networkNames $netNamesArr
    import-lig1Frame -ligName $ligName -internalNetwork $internalNetwork 

    $ligfcName          = "ligfc-Student{0}" -f $studentID.ToString('00') 
    $upltop             = "fc-Top-Student{0}"     -f  $studentID.ToString('00') 
    $uplbottom          = "fc-Bottom-Student{0}"  -f  $studentID.ToString('00') 
    import-fcnetwork    -netName $upltop
    import-fcnetwork    -netName $uplbottom 
    import-ligfc -ligName $ligfcName -upltop $upltop -uplbottom $uplbottom
}



Disconnect-OVMgmt