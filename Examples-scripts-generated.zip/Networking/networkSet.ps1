﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


write-host -foreground CYAN "----- Creating networkset Deployment "
$net                                       = get-OVNetworkSet | where name -eq 'Deployment' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "Deployment"
    $name                                  = "Deployment"
    $pBandwidth                            = 2500
    $mBandwidth                            = 10000
    $networks                              = @("ICSP","VMware Autodeploy") | % { get-OVNetwork -name $_ }
    $untaggedNetwork                       = "ICSP"


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -Networks $networks -UntaggedNetwork $nativeNetwork
} # 
else
{
    write-host -foreground YELLOW 'Deployment' already exists.
}


write-host -foreground CYAN "----- Creating networkset Mgmt "
$net                                       = get-OVNetworkSet | where name -eq 'Mgmt' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "Mgmt"
    $name                                  = "Mgmt"
    $pBandwidth                            = 2500
    $mBandwidth                            = 10000
    $networks                              = @("Management","Corporate 16") | % { get-OVNetwork -name $_ }


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -Networks $networks
} # 
else
{
    write-host -foreground YELLOW 'Mgmt' already exists.
}


write-host -foreground CYAN "----- Creating networkset NCSCephStorageTrunk "
$net                                       = get-OVNetworkSet | where name -eq 'NCSCephStorageTrunk' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "NCSCephStorageTrunk"
    $name                                  = "NCSCephStorageTrunk"
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $networks                              = @("NCS OSDInternal","NCS OSDClient") | % { get-OVNetwork -name $_ }


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -Networks $networks
} # 
else
{
    write-host -foreground YELLOW 'NCSCephStorageTrunk' already exists.
}


write-host -foreground CYAN "----- Creating networkset NCSCloudDataTrunk "
$net                                       = get-OVNetworkSet | where name -eq 'NCSCloudDataTrunk' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "NCSCloudDataTrunk"
    $name                                  = "NCSCloudDataTrunk"
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $networks                              = @("NCS Tenant168","NCS Tenant165","NCS Tenant158","NCS Tenant166","NCS Tenant160","NCS Tenant159","NCS Tenant157","NCS Tenant163","NCS Tenant161","NCS Tenant152","NCS Tenant156","NCS Tenant154","NCS Tenant162","NCS Tenant155","NCS Tenant153","NCS Tenant169","NCS Tenant167","NCS EXTERNAL","NCS Tenant164","NCS Tenant151") | % { get-OVNetwork -name $_ }


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -Networks $networks
} # 
else
{
    write-host -foreground YELLOW 'NCSCloudDataTrunk' already exists.
}


write-host -foreground CYAN "----- Creating networkset NCSESXServicesTrunk "
$net                                       = get-OVNetworkSet | where name -eq 'NCSESXServicesTrunk' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "NCSESXServicesTrunk"
    $name                                  = "NCSESXServicesTrunk"
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $networks                              = @("NCS ESX FT 123","NCS ESX VMOTION 122","NCS ESX VSAN 121") | % { get-OVNetwork -name $_ }


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -Networks $networks
} # 
else
{
    write-host -foreground YELLOW 'NCSESXServicesTrunk' already exists.
}


write-host -foreground CYAN "----- Creating networkset NCSMgmtTrunk "
$net                                       = get-OVNetworkSet | where name -eq 'NCSMgmtTrunk' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "NCSMgmtTrunk"
    $name                                  = "NCSMgmtTrunk"
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $networks                              = @("NCS Mgmt Services","NCS Hosts Management") | % { get-OVNetwork -name $_ }


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -Networks $networks
} # 
else
{
    write-host -foreground YELLOW 'NCSMgmtTrunk' already exists.
}


write-host -foreground CYAN "----- Creating networkset NHITSCloudDataTRUNK "
$net                                       = get-OVNetworkSet | where name -eq 'NHITSCloudDataTRUNK' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "NHITSCloudDataTRUNK"
    $name                                  = "NHITSCloudDataTRUNK"
    $pBandwidth                            = 2500
    $mBandwidth                            = 10000
    $networks                              = @("NHITSTenant31","NHITSTenant11","NHITSTenant52","NHITSTenant21","NHITSEXT1","NHITSTenant41","NHITSTenant43","NHITSTenant13","NHITSTenant32","NHITSTenant53","NHITSTenant23","NHITSTenant33","NHITSEXT2","NHITSTenant42","NHITSTenant51","NHITSTenant22","NHITSEXT3","NHITSTenant12") | % { get-OVNetwork -name $_ }


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -Networks $networks
} # 
else
{
    write-host -foreground YELLOW 'NHITSCloudDataTRUNK' already exists.
}


write-host -foreground CYAN "----- Creating networkset NHITSESXServicesTRUNK "
$net                                       = get-OVNetworkSet | where name -eq 'NHITSESXServicesTRUNK' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "NHITSESXServicesTRUNK"
    $name                                  = "NHITSESXServicesTRUNK"
    $pBandwidth                            = 2500
    $mBandwidth                            = 10000
    $networks                              = @("NHITSESXFT3","NHITSESXVMotion2","NHITSESXVMotion3","NHITSESXFT1","NHITSESXVMotion1","NHITSESXFT2") | % { get-OVNetwork -name $_ }


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -Networks $networks
} # 
else
{
    write-host -foreground YELLOW 'NHITSESXServicesTRUNK' already exists.
}


write-host -foreground CYAN "----- Creating networkset NHITSMGMTTRUNK "
$net                                       = get-OVNetworkSet | where name -eq 'NHITSMGMTTRUNK' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "NHITSMGMTTRUNK"
    $name                                  = "NHITSMGMTTRUNK"
    $pBandwidth                            = 2500
    $mBandwidth                            = 10000
    $networks                              = @("NHITSMGMT3","NHITSMS3","NHITSMS1","NHITSMGMT2","NHITSMGMT1","NHITSMS2") | % { get-OVNetwork -name $_ }


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -Networks $networks
} # 
else
{
    write-host -foreground YELLOW 'NHITSMGMTTRUNK' already exists.
}


write-host -foreground CYAN "----- Creating networkset ns_vmotion "
$net                                       = get-OVNetworkSet | where name -eq 'ns_vmotion' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "ns_vmotion"
    $name                                  = "ns_vmotion"
    $pBandwidth                            = 2500
    $mBandwidth                            = 10000
    $networks                              = @("ns_vmotion") | % { get-OVNetwork -name $_ }


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -Networks $networks
} # 
else
{
    write-host -foreground YELLOW 'ns_vmotion' already exists.
}


write-host -foreground CYAN "----- Creating networkset OpenStack "
$net                                       = get-OVNetworkSet | where name -eq 'OpenStack' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "OpenStack"
    $name                                  = "OpenStack"
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $networks                              = @("openstack_200") | % { get-OVNetwork -name $_ }
    $untaggedNetwork                       = "openstack_200"


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -Networks $networks -UntaggedNetwork $nativeNetwork
} # 
else
{
    write-host -foreground YELLOW 'OpenStack' already exists.
}


write-host -foreground CYAN "----- Creating networkset provisioning "
$net                                       = get-OVNetworkSet | where name -eq 'provisioning' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "provisioning"
    $name                                  = "provisioning"
    $pBandwidth                            = 2500
    $mBandwidth                            = 10000


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth
} # 
else
{
    write-host -foreground YELLOW 'provisioning' already exists.
}


write-host -foreground CYAN "----- Creating networkset Python-NCSMgmtTrunk "
$net                                       = get-OVNetworkSet | where name -eq 'Python-NCSMgmtTrunk' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "Python-NCSMgmtTrunk"
    $name                                  = "Python-NCSMgmtTrunk"
    $pBandwidth                            = 7400
    $mBandwidth                            = 20000
    $networks                              = @("NCS OSDCluster","NCS Mgmt Services","NCS Hosts Management") | % { get-OVNetwork -name $_ }


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -Networks $networks
} # 
else
{
    write-host -foreground YELLOW 'Python-NCSMgmtTrunk' already exists.
}


write-host -foreground CYAN "----- Creating networkset v13-NS "
$net                                       = get-OVNetworkSet | where name -eq 'v13-NS' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "v13-NS"
    $name                                  = "v13-NS"
    $pBandwidth                            = 2500
    $mBandwidth                            = 10000
    $networks                              = @("san-pdb-1") | % { get-OVNetwork -name $_ }


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -Networks $networks
} # 
else
{
    write-host -foreground YELLOW 'v13-NS' already exists.
}


write-host -foreground CYAN "----- Creating networkset vlan_20 "
$net                                       = get-OVNetworkSet | where name -eq 'vlan_20' 
if ($Null -eq $net )
{
    # -------------- Attributes for Network Set "vlan_20"
    $name                                  = "vlan_20"
    $pBandwidth                            = 2500
    $mBandwidth                            = 10000


    New-OVNetworkSet -Name $name -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth
} # 
else
{
    write-host -foreground YELLOW 'vlan_20' already exists.
}


Disconnect-OVMgmt
