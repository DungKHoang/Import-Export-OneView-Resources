﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


write-host -foreground CYAN "----- Creating uplinkset Corporate on LIG LIG-VC3"
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'LIG-VC3' 
$upl                                       = $lig.uplinksets | where name -eq  "Corporate" 


if ( ($lig -ne $Null) -and ($upl -eq $Null) )
{
    # -------------- Attributes for uplinkset Corporate on LIG LIG-VC3
    $name                                  = "Corporate"
    $networkType                           = "Ethernet"
    $uplConsistency                        = "Exact"
    $networks                              = @("Corporate 16") | % { get-OVNetwork -name $_ }
    $nativeNetwork                         = get-OVNetwork -name 'Corporate 16' 
    $lacpTimer                             = 'Short'
    $lacpLoadbalancingMode                 = 'SourceAndDestinationMac'
    $uplinkPorts                           = @("Enclosure1:Bay3:Q1","Enclosure2:Bay6:Q1")


    New-OVUplinkSet -InputObject $lig -Name $name -Type $networkType `
                 -Networks $networks -NativeEthNetwork $nativeNetwork -LacpTimer $lacpTimer -LacpLoadbalancingMode $lacpLoadbalancingMode `
                 -UplinkPorts $uplinkPorts `
                 -ConsistencyChecking $uplConsistency


} # 
else
{
    write-host -foreground YELLOW LIG-VC3 does not exist or Corporate already exists.
}


write-host -foreground CYAN "----- Creating uplinkset FC-A on LIG LIG-VC3"
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'LIG-VC3' 
$upl                                       = $lig.uplinksets | where name -eq  "FC-A" 


if ( ($lig -ne $Null) -and ($upl -eq $Null) )
{
    # -------------- Attributes for uplinkset FC-A on LIG LIG-VC3
    $name                                  = "FC-A"
    $networkType                           = "FibreChannel"
    $uplConsistency                        = "Exact"
    $networks                              = @("FC Discover top") | % { get-OVNetwork -name $_ }
    $enableTrunking                        = $False
    $fcUplinkSpeed                         = 'Auto'
    $uplinkPorts                           = @("Enclosure1:Bay3:Q5.1")


    New-OVUplinkSet -InputObject $lig -Name $name -Type $networkType `
                 -Networks $networks -fcUplinkSpeed $fcUplinkSpeed `
                 -UplinkPorts $uplinkPorts `
                 -ConsistencyChecking $uplConsistency


} # 
else
{
    write-host -foreground YELLOW LIG-VC3 does not exist or FC-A already exists.
}


write-host -foreground CYAN "----- Creating uplinkset FC-B on LIG LIG-VC3"
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'LIG-VC3' 
$upl                                       = $lig.uplinksets | where name -eq  "FC-B" 


if ( ($lig -ne $Null) -and ($upl -eq $Null) )
{
    # -------------- Attributes for uplinkset FC-B on LIG LIG-VC3
    $name                                  = "FC-B"
    $networkType                           = "FibreChannel"
    $uplConsistency                        = "Exact"
    $networks                              = @("FC Discover bottom") | % { get-OVNetwork -name $_ }
    $enableTrunking                        = $False
    $fcUplinkSpeed                         = 'Auto'
    $uplinkPorts                           = @("Enclosure2:Bay6:Q5.1")


    New-OVUplinkSet -InputObject $lig -Name $name -Type $networkType `
                 -Networks $networks -fcUplinkSpeed $fcUplinkSpeed `
                 -UplinkPorts $uplinkPorts `
                 -ConsistencyChecking $uplConsistency


} # 
else
{
    write-host -foreground YELLOW LIG-VC3 does not exist or FC-B already exists.
}


write-host -foreground CYAN "----- Creating uplinkset I3S on LIG LIG-VC3"
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'LIG-VC3' 
$upl                                       = $lig.uplinksets | where name -eq  "I3S" 


if ( ($lig -ne $Null) -and ($upl -eq $Null) )
{
    # -------------- Attributes for uplinkset I3S on LIG LIG-VC3
    $name                                  = "I3S"
    $networkType                           = "ImageStreamer"
    $uplConsistency                        = "Exact"
    $networks                              = @("IS iSCSI") | % { get-OVNetwork -name $_ }
    $lacpTimer                             = 'Short'
    $lacpLoadbalancingMode                 = 'SourceAndDestinationMac'
    $uplinkPorts                           = @("Enclosure1:Bay3:Q2.1","Enclosure1:Bay3:Q3.1","Enclosure2:Bay6:Q2.1","Enclosure2:Bay6:Q3.1")


    New-OVUplinkSet -InputObject $lig -Name $name -Type $networkType `
                 -Networks $networks -LacpTimer $lacpTimer -LacpLoadbalancingMode $lacpLoadbalancingMode `
                 -UplinkPorts $uplinkPorts `
                 -ConsistencyChecking $uplConsistency


} # 
else
{
    write-host -foreground YELLOW LIG-VC3 does not exist or I3S already exists.
}


write-host -foreground CYAN "----- Creating uplinkset Management on LIG LIG-VC3"
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'LIG-VC3' 
$upl                                       = $lig.uplinksets | where name -eq  "Management" 


if ( ($lig -ne $Null) -and ($upl -eq $Null) )
{
    # -------------- Attributes for uplinkset Management on LIG LIG-VC3
    $name                                  = "Management"
    $networkType                           = "Ethernet"
    $uplConsistency                        = "Exact"
    $networks                              = @("NCS OSDCluster","NCS OSDInternal","NCS Tenant168","NCS Tenant158","NCS Tenant166","NCS Tenant163","NCS Tenant154","NCS Tenant162","NCS Tenant155","NCS Tenant169","NCS OSDClient","NCS Mgmt Services","ICSP","openstack_200","NCS Tenant165","NCS Tenant160","NCS Tenant159","NCS Tenant157","NCS Hosts Management","Management","NCS Tenant161","NCS Tenant152","NCS Tenant156","NCS Tenant153","NCS Tenant167","NCS EXTERNAL","NCS Tenant164","NCS Tenant151") | % { get-OVNetwork -name $_ }
    $nativeNetwork                         = get-OVNetwork -name 'Management' 
    $lacpTimer                             = 'Short'
    $lacpLoadbalancingMode                 = 'SourceAndDestinationMac'
    $uplinkPorts                           = @("Enclosure1:Bay3:Q4.1","Enclosure2:Bay6:Q4.1")


    New-OVUplinkSet -InputObject $lig -Name $name -Type $networkType `
                 -Networks $networks -NativeEthNetwork $nativeNetwork -LacpTimer $lacpTimer -LacpLoadbalancingMode $lacpLoadbalancingMode `
                 -UplinkPorts $uplinkPorts `
                 -ConsistencyChecking $uplConsistency


} # 
else
{
    write-host -foreground YELLOW LIG-VC3 does not exist or Management already exists.
}


write-host -foreground CYAN "----- Creating uplinkset PUBLIC on LIG LIG-VC3"
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'LIG-VC3' 
$upl                                       = $lig.uplinksets | where name -eq  "PUBLIC" 


if ( ($lig -ne $Null) -and ($upl -eq $Null) )
{
    # -------------- Attributes for uplinkset PUBLIC on LIG LIG-VC3
    $name                                  = "PUBLIC"
    $networkType                           = "Untagged"
    $uplConsistency                        = "Exact"
    $networks                              = @("Public-HOL-Net") | % { get-OVNetwork -name $_ }
    $lacpTimer                             = 'Short'
    $lacpLoadbalancingMode                 = 'SourceAndDestinationMac'
    $uplinkPorts                           = @("Enclosure1:Bay3:Q6.1")


    New-OVUplinkSet -InputObject $lig -Name $name -Type $networkType `
                 -Networks $networks -LacpTimer $lacpTimer -LacpLoadbalancingMode $lacpLoadbalancingMode `
                 -UplinkPorts $uplinkPorts `
                 -ConsistencyChecking $uplConsistency


} # 
else
{
    write-host -foreground YELLOW LIG-VC3 does not exist or PUBLIC already exists.
}


write-host -foreground CYAN "----- Creating uplinkset FC-A on LIG OBT-LIG-FC2-5"
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'OBT-LIG-FC2-5' 
$upl                                       = $lig.uplinksets | where name -eq  "FC-A" 


if ( ($lig -ne $Null) -and ($upl -eq $Null) )
{
    # -------------- Attributes for uplinkset FC-A on LIG OBT-LIG-FC2-5
    $name                                  = "FC-A"
    $networkType                           = "FibreChannel"
    $uplConsistency                        = "Exact"
    $networks                              = @("FC Discover top") | % { get-OVNetwork -name $_ }
    $enableTrunking                        = $True
    $fcUplinkSpeed                         = 'Auto'
    $uplinkPorts                           = @("Bay2:2","Bay2:3")


    New-OVUplinkSet -InputObject $lig -Name $name -Type $networkType `
                 -Networks $networks -fcUplinkSpeed $fcUplinkSpeed `
                 -UplinkPorts $uplinkPorts `
                 -ConsistencyChecking $uplConsistency


} # 
else
{
    write-host -foreground YELLOW OBT-LIG-FC2-5 does not exist or FC-A already exists.
}


write-host -foreground CYAN "----- Creating uplinkset FC-B on LIG OBT-LIG-FC2-5"
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'OBT-LIG-FC2-5' 
$upl                                       = $lig.uplinksets | where name -eq  "FC-B" 


if ( ($lig -ne $Null) -and ($upl -eq $Null) )
{
    # -------------- Attributes for uplinkset FC-B on LIG OBT-LIG-FC2-5
    $name                                  = "FC-B"
    $networkType                           = "FibreChannel"
    $uplConsistency                        = "Exact"
    $networks                              = @("FC Discover bottom") | % { get-OVNetwork -name $_ }
    $enableTrunking                        = $False
    $fcUplinkSpeed                         = '8'
    $uplinkPorts                           = @("Bay5:7","Bay5:8")


    New-OVUplinkSet -InputObject $lig -Name $name -Type $networkType `
                 -Networks $networks -fcUplinkSpeed $fcUplinkSpeed `
                 -UplinkPorts $uplinkPorts `
                 -ConsistencyChecking $uplConsistency


} # 
else
{
    write-host -foreground YELLOW OBT-LIG-FC2-5 does not exist or FC-B already exists.
}


write-host -foreground CYAN "----- Creating uplinkset FC-A on LIG PYTHON-OBT-LIG-FC2-5"
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'PYTHON-OBT-LIG-FC2-5' 
$upl                                       = $lig.uplinksets | where name -eq  "FC-A" 


if ( ($lig -ne $Null) -and ($upl -eq $Null) )
{
    # -------------- Attributes for uplinkset FC-A on LIG PYTHON-OBT-LIG-FC2-5
    $name                                  = "FC-A"
    $networkType                           = "FibreChannel"
    $uplConsistency                        = "Exact"
    $networks                              = @("FC Discover top") | % { get-OVNetwork -name $_ }
    $enableTrunking                        = $False
    $fcUplinkSpeed                         = 'Auto'
    $uplinkPorts                           = @("Bay2:2","Bay2:3")


    New-OVUplinkSet -InputObject $lig -Name $name -Type $networkType `
                 -Networks $networks -fcUplinkSpeed $fcUplinkSpeed `
                 -UplinkPorts $uplinkPorts `
                 -ConsistencyChecking $uplConsistency


} # 
else
{
    write-host -foreground YELLOW PYTHON-OBT-LIG-FC2-5 does not exist or FC-A already exists.
}


write-host -foreground CYAN "----- Creating uplinkset FC-B on LIG PYTHON-OBT-LIG-FC2-5"
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'PYTHON-OBT-LIG-FC2-5' 
$upl                                       = $lig.uplinksets | where name -eq  "FC-B" 


if ( ($lig -ne $Null) -and ($upl -eq $Null) )
{
    # -------------- Attributes for uplinkset FC-B on LIG PYTHON-OBT-LIG-FC2-5
    $name                                  = "FC-B"
    $networkType                           = "FibreChannel"
    $uplConsistency                        = "Exact"
    $networks                              = @("FC Discover bottom") | % { get-OVNetwork -name $_ }
    $enableTrunking                        = $False
    $fcUplinkSpeed                         = '8'
    $uplinkPorts                           = @("Bay5:7","Bay5:8")


    New-OVUplinkSet -InputObject $lig -Name $name -Type $networkType `
                 -Networks $networks -fcUplinkSpeed $fcUplinkSpeed `
                 -UplinkPorts $uplinkPorts `
                 -ConsistencyChecking $uplConsistency


} # 
else
{
    write-host -foreground YELLOW PYTHON-OBT-LIG-FC2-5 does not exist or FC-B already exists.
}


Disconnect-OVMgmt
