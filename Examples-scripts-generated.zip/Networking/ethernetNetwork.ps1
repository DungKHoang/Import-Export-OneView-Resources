﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


write-host -foreground CYAN "----- Creating ethernet networks ch_oam_3 "
$net                                       = get-OVNetwork | where name -eq 'ch_oam_3' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "ch_oam_3"
    $name                                  = "ch_oam_3"
    $vLANType                              = "Tagged"
    $vLANid                                = 2000
    $pBandwidth                            = 1000
    $mBandwidth                            = 1000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'ch_oam_3' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks Corporate 16 "
$net                                       = get-OVNetwork | where name -eq 'Corporate 16' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "Corporate 16"
    $name                                  = "Corporate 16"
    $vLANType                              = "Tagged"
    $vLANid                                = 16
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'Corporate 16' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks ctrl_emm_1310 "
$net                                       = get-OVNetwork | where name -eq 'ctrl_emm_1310' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "ctrl_emm_1310"
    $name                                  = "ctrl_emm_1310"
    $vLANType                              = "Tagged"
    $vLANid                                = 1310
    $pBandwidth                            = 1000
    $mBandwidth                            = 1000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'ctrl_emm_1310' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks ddb-sync-netw "
$net                                       = get-OVNetwork | where name -eq 'ddb-sync-netw' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "ddb-sync-netw"
    $name                                  = "ddb-sync-netw"
    $vLANType                              = "Tagged"
    $vLANid                                = 1302
    $pBandwidth                            = 1000
    $mBandwidth                            = 1000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'ddb-sync-netw' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks ecm_access_503 "
$net                                       = get-OVNetwork | where name -eq 'ecm_access_503' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "ecm_access_503"
    $name                                  = "ecm_access_503"
    $vLANType                              = "Tagged"
    $vLANid                                = 503
    $pBandwidth                            = 1000
    $mBandwidth                            = 1000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'ecm_access_503' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks ecm_oam_NS "
$net                                       = get-OVNetwork | where name -eq 'ecm_oam_NS' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "ecm_oam_NS"
    $name                                  = "ecm_oam_NS"
    $vLANType                              = "Tagged"
    $vLANid                                = 500
    $pBandwidth                            = 1000
    $mBandwidth                            = 1000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'ecm_oam_NS' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks emm_ban_2 "
$net                                       = get-OVNetwork | where name -eq 'emm_ban_2' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "emm_ban_2"
    $name                                  = "emm_ban_2"
    $vLANType                              = "Tagged"
    $vLANid                                = 3502
    $pBandwidth                            = 1000
    $mBandwidth                            = 1000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'emm_ban_2' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks emm_oam_1 "
$net                                       = get-OVNetwork | where name -eq 'emm_oam_1' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "emm_oam_1"
    $name                                  = "emm_oam_1"
    $vLANType                              = "Tagged"
    $vLANid                                = 1130
    $pBandwidth                            = 1000
    $mBandwidth                            = 1000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'emm_oam_1' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks emm_oam_3 "
$net                                       = get-OVNetwork | where name -eq 'emm_oam_3' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "emm_oam_3"
    $name                                  = "emm_oam_3"
    $vLANType                              = "Tagged"
    $vLANid                                = 1131
    $pBandwidth                            = 1000
    $mBandwidth                            = 1000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'emm_oam_3' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks emm_traffic_3 "
$net                                       = get-OVNetwork | where name -eq 'emm_traffic_3' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "emm_traffic_3"
    $name                                  = "emm_traffic_3"
    $vLANType                              = "Tagged"
    $vLANid                                = 1311
    $pBandwidth                            = 1000
    $mBandwidth                            = 1000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'emm_traffic_3' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks emm-ban-1 "
$net                                       = get-OVNetwork | where name -eq 'emm-ban-1' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "emm-ban-1"
    $name                                  = "emm-ban-1"
    $vLANType                              = "Tagged"
    $vLANid                                = 3501
    $pBandwidth                            = 1000
    $mBandwidth                            = 1000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'emm-ban-1' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks ICSP "
$net                                       = get-OVNetwork | where name -eq 'ICSP' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "ICSP"
    $name                                  = "ICSP"
    $vLANType                              = "Tagged"
    $vLANid                                = 3
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'ICSP' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks IS iSCSI "
$net                                       = get-OVNetwork | where name -eq 'IS iSCSI' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "IS iSCSI"
    $name                                  = "IS iSCSI"
    $vLANType                              = "Tagged"
    $vLANid                                = 8
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $ipV4subnet                            = Get-OVAddressPoolSubnet -NetworkID '192.168.8.0'
    $subnet                                = @($ipV4subnet)
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "ISCSI"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -subnet $subnet


} # 
else
{
    write-host -foreground YELLOW 'IS iSCSI' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks iSCSI VSA "
$net                                       = get-OVNetwork | where name -eq 'iSCSI VSA' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "iSCSI VSA"
    $name                                  = "iSCSI VSA"
    $vLANType                              = "Tagged"
    $vLANid                                = 55
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "ISCSI"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'iSCSI VSA' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks Management "
$net                                       = get-OVNetwork | where name -eq 'Management' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "Management"
    $name                                  = "Management"
    $vLANType                              = "Tagged"
    $vLANid                                = 2
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $ipV4subnet                            = Get-OVAddressPoolSubnet -NetworkID '192.168.0.0'
    $subnet                                = @($ipV4subnet)
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "Management"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth -subnet $subnet


} # 
else
{
    write-host -foreground YELLOW 'Management' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS ESX FT 123 "
$net                                       = get-OVNetwork | where name -eq 'NCS ESX FT 123' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS ESX FT 123"
    $name                                  = "NCS ESX FT 123"
    $vLANType                              = "Tagged"
    $vLANid                                = 123
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS ESX FT 123' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS ESX VMOTION 122 "
$net                                       = get-OVNetwork | where name -eq 'NCS ESX VMOTION 122' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS ESX VMOTION 122"
    $name                                  = "NCS ESX VMOTION 122"
    $vLANType                              = "Tagged"
    $vLANid                                = 122
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS ESX VMOTION 122' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS ESX VSAN 121 "
$net                                       = get-OVNetwork | where name -eq 'NCS ESX VSAN 121' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS ESX VSAN 121"
    $name                                  = "NCS ESX VSAN 121"
    $vLANType                              = "Tagged"
    $vLANid                                = 121
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS ESX VSAN 121' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS EXTERNAL "
$net                                       = get-OVNetwork | where name -eq 'NCS EXTERNAL' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS EXTERNAL"
    $name                                  = "NCS EXTERNAL"
    $vLANType                              = "Tagged"
    $vLANid                                = 171
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS EXTERNAL' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Hosts Management "
$net                                       = get-OVNetwork | where name -eq 'NCS Hosts Management' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Hosts Management"
    $name                                  = "NCS Hosts Management"
    $vLANType                              = "Tagged"
    $vLANid                                = 111
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Hosts Management' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Mgmt Services "
$net                                       = get-OVNetwork | where name -eq 'NCS Mgmt Services' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Mgmt Services"
    $name                                  = "NCS Mgmt Services"
    $vLANType                              = "Tagged"
    $vLANid                                = 112
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Mgmt Services' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS OSDClient "
$net                                       = get-OVNetwork | where name -eq 'NCS OSDClient' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS OSDClient"
    $name                                  = "NCS OSDClient"
    $vLANType                              = "Tagged"
    $vLANid                                = 182
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS OSDClient' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS OSDCluster "
$net                                       = get-OVNetwork | where name -eq 'NCS OSDCluster' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS OSDCluster"
    $name                                  = "NCS OSDCluster"
    $vLANType                              = "Tagged"
    $vLANid                                = 183
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS OSDCluster' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS OSDInternal "
$net                                       = get-OVNetwork | where name -eq 'NCS OSDInternal' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS OSDInternal"
    $name                                  = "NCS OSDInternal"
    $vLANType                              = "Tagged"
    $vLANid                                = 181
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS OSDInternal' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant151 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant151' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant151"
    $name                                  = "NCS Tenant151"
    $vLANType                              = "Tagged"
    $vLANid                                = 151
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant151' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant152 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant152' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant152"
    $name                                  = "NCS Tenant152"
    $vLANType                              = "Tagged"
    $vLANid                                = 152
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant152' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant153 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant153' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant153"
    $name                                  = "NCS Tenant153"
    $vLANType                              = "Tagged"
    $vLANid                                = 153
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant153' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant154 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant154' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant154"
    $name                                  = "NCS Tenant154"
    $vLANType                              = "Tagged"
    $vLANid                                = 154
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant154' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant155 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant155' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant155"
    $name                                  = "NCS Tenant155"
    $vLANType                              = "Tagged"
    $vLANid                                = 155
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant155' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant156 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant156' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant156"
    $name                                  = "NCS Tenant156"
    $vLANType                              = "Tagged"
    $vLANid                                = 156
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant156' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant157 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant157' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant157"
    $name                                  = "NCS Tenant157"
    $vLANType                              = "Tagged"
    $vLANid                                = 157
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant157' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant158 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant158' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant158"
    $name                                  = "NCS Tenant158"
    $vLANType                              = "Tagged"
    $vLANid                                = 158
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant158' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant159 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant159' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant159"
    $name                                  = "NCS Tenant159"
    $vLANType                              = "Tagged"
    $vLANid                                = 159
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant159' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant160 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant160' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant160"
    $name                                  = "NCS Tenant160"
    $vLANType                              = "Tagged"
    $vLANid                                = 160
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant160' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant161 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant161' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant161"
    $name                                  = "NCS Tenant161"
    $vLANType                              = "Tagged"
    $vLANid                                = 161
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant161' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant162 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant162' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant162"
    $name                                  = "NCS Tenant162"
    $vLANType                              = "Tagged"
    $vLANid                                = 162
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant162' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant163 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant163' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant163"
    $name                                  = "NCS Tenant163"
    $vLANType                              = "Tagged"
    $vLANid                                = 163
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant163' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant164 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant164' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant164"
    $name                                  = "NCS Tenant164"
    $vLANType                              = "Tagged"
    $vLANid                                = 164
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant164' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant165 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant165' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant165"
    $name                                  = "NCS Tenant165"
    $vLANType                              = "Tagged"
    $vLANid                                = 165
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant165' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant166 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant166' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant166"
    $name                                  = "NCS Tenant166"
    $vLANType                              = "Tagged"
    $vLANid                                = 166
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant166' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant167 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant167' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant167"
    $name                                  = "NCS Tenant167"
    $vLANType                              = "Tagged"
    $vLANid                                = 167
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant167' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant168 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant168' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant168"
    $name                                  = "NCS Tenant168"
    $vLANType                              = "Tagged"
    $vLANid                                = 168
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant168' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NCS Tenant169 "
$net                                       = get-OVNetwork | where name -eq 'NCS Tenant169' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NCS Tenant169"
    $name                                  = "NCS Tenant169"
    $vLANType                              = "Tagged"
    $vLANid                                = 169
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NCS Tenant169' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSESXFT1 "
$net                                       = get-OVNetwork | where name -eq 'NHITSESXFT1' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSESXFT1"
    $name                                  = "NHITSESXFT1"
    $vLANType                              = "Tagged"
    $vLANid                                = 1114
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSESXFT1' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSESXFT2 "
$net                                       = get-OVNetwork | where name -eq 'NHITSESXFT2' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSESXFT2"
    $name                                  = "NHITSESXFT2"
    $vLANType                              = "Tagged"
    $vLANid                                = 1124
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSESXFT2' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSESXFT3 "
$net                                       = get-OVNetwork | where name -eq 'NHITSESXFT3' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSESXFT3"
    $name                                  = "NHITSESXFT3"
    $vLANType                              = "Tagged"
    $vLANid                                = 1134
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSESXFT3' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSESXVMotion1 "
$net                                       = get-OVNetwork | where name -eq 'NHITSESXVMotion1' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSESXVMotion1"
    $name                                  = "NHITSESXVMotion1"
    $vLANType                              = "Tagged"
    $vLANid                                = 1113
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSESXVMotion1' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSESXVMotion2 "
$net                                       = get-OVNetwork | where name -eq 'NHITSESXVMotion2' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSESXVMotion2"
    $name                                  = "NHITSESXVMotion2"
    $vLANType                              = "Tagged"
    $vLANid                                = 1123
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSESXVMotion2' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSESXVMotion3 "
$net                                       = get-OVNetwork | where name -eq 'NHITSESXVMotion3' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSESXVMotion3"
    $name                                  = "NHITSESXVMotion3"
    $vLANType                              = "Tagged"
    $vLANid                                = 1133
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSESXVMotion3' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSEXT1 "
$net                                       = get-OVNetwork | where name -eq 'NHITSEXT1' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSEXT1"
    $name                                  = "NHITSEXT1"
    $vLANType                              = "Tagged"
    $vLANid                                = 1111
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSEXT1' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSEXT2 "
$net                                       = get-OVNetwork | where name -eq 'NHITSEXT2' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSEXT2"
    $name                                  = "NHITSEXT2"
    $vLANType                              = "Tagged"
    $vLANid                                = 1121
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSEXT2' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSEXT3 "
$net                                       = get-OVNetwork | where name -eq 'NHITSEXT3' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSEXT3"
    $name                                  = "NHITSEXT3"
    $vLANType                              = "Tagged"
    $vLANid                                = 1131
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSEXT3' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSMGMT1 "
$net                                       = get-OVNetwork | where name -eq 'NHITSMGMT1' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSMGMT1"
    $name                                  = "NHITSMGMT1"
    $vLANType                              = "Tagged"
    $vLANid                                = 1110
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSMGMT1' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSMGMT2 "
$net                                       = get-OVNetwork | where name -eq 'NHITSMGMT2' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSMGMT2"
    $name                                  = "NHITSMGMT2"
    $vLANType                              = "Tagged"
    $vLANid                                = 1120
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSMGMT2' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSMGMT3 "
$net                                       = get-OVNetwork | where name -eq 'NHITSMGMT3' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSMGMT3"
    $name                                  = "NHITSMGMT3"
    $vLANType                              = "Tagged"
    $vLANid                                = 1130
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSMGMT3' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSMS1 "
$net                                       = get-OVNetwork | where name -eq 'NHITSMS1' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSMS1"
    $name                                  = "NHITSMS1"
    $vLANType                              = "Tagged"
    $vLANid                                = 1112
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSMS1' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSMS2 "
$net                                       = get-OVNetwork | where name -eq 'NHITSMS2' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSMS2"
    $name                                  = "NHITSMS2"
    $vLANType                              = "Tagged"
    $vLANid                                = 1122
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSMS2' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSMS3 "
$net                                       = get-OVNetwork | where name -eq 'NHITSMS3' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSMS3"
    $name                                  = "NHITSMS3"
    $vLANType                              = "Tagged"
    $vLANid                                = 1132
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSMS3' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant11 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant11' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant11"
    $name                                  = "NHITSTenant11"
    $vLANType                              = "Tagged"
    $vLANid                                = 1115
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant11' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant12 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant12' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant12"
    $name                                  = "NHITSTenant12"
    $vLANType                              = "Tagged"
    $vLANid                                = 1125
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant12' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant13 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant13' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant13"
    $name                                  = "NHITSTenant13"
    $vLANType                              = "Tagged"
    $vLANid                                = 1135
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant13' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant21 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant21' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant21"
    $name                                  = "NHITSTenant21"
    $vLANType                              = "Tagged"
    $vLANid                                = 1116
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant21' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant22 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant22' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant22"
    $name                                  = "NHITSTenant22"
    $vLANType                              = "Tagged"
    $vLANid                                = 1126
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant22' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant23 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant23' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant23"
    $name                                  = "NHITSTenant23"
    $vLANType                              = "Tagged"
    $vLANid                                = 1136
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant23' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant31 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant31' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant31"
    $name                                  = "NHITSTenant31"
    $vLANType                              = "Tagged"
    $vLANid                                = 1117
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant31' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant32 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant32' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant32"
    $name                                  = "NHITSTenant32"
    $vLANType                              = "Tagged"
    $vLANid                                = 1127
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant32' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant33 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant33' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant33"
    $name                                  = "NHITSTenant33"
    $vLANType                              = "Tagged"
    $vLANid                                = 1137
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant33' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant41 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant41' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant41"
    $name                                  = "NHITSTenant41"
    $vLANType                              = "Tagged"
    $vLANid                                = 1118
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant41' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant42 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant42' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant42"
    $name                                  = "NHITSTenant42"
    $vLANType                              = "Tagged"
    $vLANid                                = 1128
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant42' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant43 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant43' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant43"
    $name                                  = "NHITSTenant43"
    $vLANType                              = "Tagged"
    $vLANid                                = 1138
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant43' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant51 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant51' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant51"
    $name                                  = "NHITSTenant51"
    $vLANType                              = "Tagged"
    $vLANid                                = 1119
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant51' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant52 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant52' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant52"
    $name                                  = "NHITSTenant52"
    $vLANType                              = "Tagged"
    $vLANid                                = 1129
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant52' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks NHITSTenant53 "
$net                                       = get-OVNetwork | where name -eq 'NHITSTenant53' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "NHITSTenant53"
    $name                                  = "NHITSTenant53"
    $vLANType                              = "Tagged"
    $vLANid                                = 1139
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'NHITSTenant53' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks ns_vmotion "
$net                                       = get-OVNetwork | where name -eq 'ns_vmotion' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "ns_vmotion"
    $name                                  = "ns_vmotion"
    $vLANType                              = "Tagged"
    $vLANid                                = 1001
    $pBandwidth                            = 2500
    $mBandwidth                            = 10000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "VMMigration"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'ns_vmotion' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks oam-fee-netw "
$net                                       = get-OVNetwork | where name -eq 'oam-fee-netw' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "oam-fee-netw"
    $name                                  = "oam-fee-netw"
    $vLANType                              = "Tagged"
    $vLANid                                = 1301
    $pBandwidth                            = 1000
    $mBandwidth                            = 1000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'oam-fee-netw' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks oob-management-netw "
$net                                       = get-OVNetwork | where name -eq 'oob-management-netw' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "oob-management-netw"
    $name                                  = "oob-management-netw"
    $vLANType                              = "Tagged"
    $vLANid                                = 1300
    $pBandwidth                            = 1000
    $mBandwidth                            = 1000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'oob-management-netw' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks openstack_200 "
$net                                       = get-OVNetwork | where name -eq 'openstack_200' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "openstack_200"
    $name                                  = "openstack_200"
    $vLANType                              = "Tagged"
    $vLANid                                = 200
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'openstack_200' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks Public-HOL-Net "
$net                                       = get-OVNetwork | where name -eq 'Public-HOL-Net' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "Public-HOL-Net"
    $name                                  = "Public-HOL-Net"
    $vLANType                              = "Untagged"
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "Management"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'Public-HOL-Net' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks san-pdb-1 "
$net                                       = get-OVNetwork | where name -eq 'san-pdb-1' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "san-pdb-1"
    $name                                  = "san-pdb-1"
    $vLANType                              = "Tagged"
    $vLANid                                = 12
    $pBandwidth                            = 1000
    $mBandwidth                            = 16000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'san-pdb-1' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks Stand-By-Net "
$net                                       = get-OVNetwork | where name -eq 'Stand-By-Net' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "Stand-By-Net"
    $name                                  = "Stand-By-Net"
    $vLANType                              = "Untagged"
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $False
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'Stand-By-Net' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks vMotion "
$net                                       = get-OVNetwork | where name -eq 'vMotion' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "vMotion"
    $name                                  = "vMotion"
    $vLANType                              = "Tagged"
    $vLANid                                = 10
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "VMMigration"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'vMotion' already exists.
}


write-host -foreground CYAN "----- Creating ethernet networks VMware Autodeploy "
$net                                       = get-OVNetwork | where name -eq 'VMware Autodeploy' 
if ($Null -eq $net )
{
    # -------------- Attributes for Ethernet network "VMware Autodeploy"
    $name                                  = "VMware Autodeploy"
    $vLANType                              = "Tagged"
    $vLANid                                = 7
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $PLAN                                  = $False
    $smartLink                             = $True
    $purpose                               = "General"
    New-OVNetwork -Name $name  -PrivateNetwork $PLAN -SmartLink $smartLink -VLANType $VLANType  -purpose $purpose `
                 -VlanID $VLANID -TypicalBandwidth $pBandwidth -MaximumBandwidth $mBandwidth


} # 
else
{
    write-host -foreground YELLOW 'VMware Autodeploy' already exists.
}


Disconnect-OVMgmt
