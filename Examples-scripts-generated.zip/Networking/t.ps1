$studentID       = 1
foreach ($studentID in 226..326)
{
    $multiplier         = $studentID *10
    foreach($i in 0..9)
    {
        $vLAN           = $multiplier + $i
        $netName           = "net-VLAN{0}-Student{1}" -f $vLAN, $studentID.ToString('00') 

        write-host "network name --> $netName vLAN ---> $vLAN"
        
    }
    $netSetName            = "netSet-Student{1}" -f $vLAN, $studentID.ToString('00') 
    write-host "netset name --> $netSetName"
    write-host "`n"
}
