﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


write-host -foreground CYAN "----- Creating FC/FCOE networks FC Discover bottom "
$net                                       = get-OVNetwork -type FibreChannel | where name -eq 'FC Discover bottom'  
if ($Null -eq $net )
{
    # -------------- Attributes for FC network "FC Discover bottom"
    $name                                  = "FC Discover bottom"
    $type                                  = "FibreChannel"
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $fabricType                            = "FabricAttach"
    $autologinredistribution               = $False


    New-OVNetwork -Name $name -Type $Type `
                 -typicalBandwidth $pBandwidth -maximumBandwidth $mBandwidth -FabricType $fabricType -AutoLoginRedistribution $autologinredistribution


} # 
else
{
    write-host -foreground YELLOW 'FC Discover bottom' already exists.
}


write-host -foreground CYAN "----- Creating FC/FCOE networks FC Discover top "
$net                                       = get-OVNetwork -type FibreChannel | where name -eq 'FC Discover top'  
if ($Null -eq $net )
{
    # -------------- Attributes for FC network "FC Discover top"
    $name                                  = "FC Discover top"
    $type                                  = "FibreChannel"
    $pBandwidth                            = 2500
    $mBandwidth                            = 20000
    $fabricType                            = "FabricAttach"
    $autologinredistribution               = $False


    New-OVNetwork -Name $name -Type $Type `
                 -typicalBandwidth $pBandwidth -maximumBandwidth $mBandwidth -FabricType $fabricType -AutoLoginRedistribution $autologinredistribution


} # 
else
{
    write-host -foreground YELLOW 'FC Discover top' already exists.
}


Disconnect-OVMgmt
