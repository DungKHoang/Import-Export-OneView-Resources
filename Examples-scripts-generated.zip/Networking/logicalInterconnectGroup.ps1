﻿

write-host "`n"
write-host -foreground CYAN "----- Connecting to OneView 192.168.1.164" 
if ($global:ConnectedSessions)
{
    $d = disconnect-OVMgmt -ApplianceConnection $global:ConnectedSessions
} # 
$userName                                  =  "administrator" 
$password                                  =  "password" 
if ($password)
{
    $securePassword                        = $password | ConvertTo-SecureString -AsPlainText -Force
} # 
else
{
    $securePassword                        = Read-Host "OneView: enter password for user administrator" -AsSecureString 
}
$cred                                      = New-Object System.Management.Automation.PSCredential  -ArgumentList $userName, $securePassword


connect-OVMgmt -hostname 192.168.1.164 -credential $cred -loginAcknowledge:$True -AuthLoginDomain "LOCAL" 


write-host -foreground CYAN "----- Creating logical interconnect group LIG 2-5 " 
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'LIG 2-5' 
if ($lig -eq $Null)
{
    # -------------- Attributes for LIG "LIG 2-5"
    $name                                  = "LIG 2-5"
    $frameCount                            = 3
    $interconnectBaySet                    = 2
    $fabricModuleType                      = 'SEVC40f8'
    $redundancyType                        = "HighlyAvailable"
    $bayConfig                             = @{Frame1=@{Bay2='SEVC40f8';Bay5='SE20ILM'};Frame2=@{Bay2='SE20ILM';Bay5='SEVC40f8'};Frame3=@{Bay2='SE20ILM';Bay5='SE20ILM'}}
    $enableNetworkLoopProtection           = $True
    $enableRichTLV                         = $False
    $enableTaggedLldp                      = $False
    $lldpIpAddressMode                     = 'IPV4'
    $interconnectConsistency               = 'Exact'




    $lig = New-OVLogicalInterconnectGroup -Name $name  -fabricModuleType $fabricModuleType -frameCount $frameCount -interConnectBaySet $interConnectBaySet  `
                 -Bays $bayConfig -FabricRedundancy $redundancyType `
                 -enablenetworkLoopProtection $enableNetworkLoopProtection `
                 -enableEnhancedLLDPTLV $enableRichTLV `
                 -lldpAddressingMode $lldpIpAddressMode -enableLLDPTagging $enableTaggedLldp -interconnectConsistencyChecking $interconnectConsistency `
                 


} # if ($lig -eq $Null)
else
{
    write-host -foreground YELLOW 'LIG 2-5' already exists.
}


write-host -foreground CYAN "----- Creating logical interconnect group LIG-Ethernet " 
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'LIG-Ethernet' 
if ($lig -eq $Null)
{
    # -------------- Attributes for LIG "LIG-Ethernet"
    $name                                  = "LIG-Ethernet"
    $frameCount                            = 3
    $interconnectBaySet                    = 3
    $fabricModuleType                      = 'SEVC40f8'
    $redundancyType                        = "HighlyAvailable"
    $bayConfig                             = @{Frame1=@{Bay3='SEVC40f8';Bay6='SE20ILM'};Frame2=@{Bay3='SE20ILM';Bay6='SEVC40f8'};Frame3=@{Bay3='SE20ILM';Bay6='SE20ILM'}}
    $enableNetworkLoopProtection           = $True
    $enableRichTLV                         = $False
    $enableTaggedLldp                      = $False
    $lldpIpAddressMode                     = 'IPV4'
    $interconnectConsistency               = 'Exact'


    $communityString                       = 'ligRead'
    $contact                               = 'dung@hpe.com'


    $snmpv3Users                           = [System.Collections.ArrayList]::new()
    $snmpv3Usernames                       = [System.Collections.ArrayList]::new()


    write-host -foreground CYAN "----- Creating snmpV3 user snmpUser-Noauth " 
    $snmpv3User1                           = new-OVSnmpV3User  -UserName "snmpUser-Noauth" 


    write-host -foreground CYAN "----- Creating snmpV3 user lig-snmpUser " 
    $snmpv3User2                           = new-OVSnmpV3User  -UserName "lig-snmpUser" 


    $snmpv3Users                           = @($snmpv3User1,$snmpv3User2)
    $snmpv3Usernames                       = @('snmpUser-Noauth','lig-snmpUser')
    $this_index                            = [array]::IndexOf($snmpV3Usernames, "lig-snmpUser" )
    $snmpV3user                            = $snmpV3Users[$this_index]
    write-host -foreground CYAN '----- Creating snmp trap $trap1 '
    $trap1                                 = New-OVSnmpTrapDestination  -SnmpFormat SNMPv3  -Destination "10.10.10.10"  -Port 162  -NotificationType "Inform"  -SnmpV3user $snmpV3user 




    $snmpTraps                             = @($trap1)
    $snmpConfiguration                     = New-OVSnmpConfiguration  -snmpV1 $True -ReadCommunity $communityString  -Contact $contact  -snmpV3 $True -snmpV3Users $snmpV3Users  -TrapDestination $snmpTraps   




    $lig = New-OVLogicalInterconnectGroup -Name $name  -fabricModuleType $fabricModuleType -frameCount $frameCount -interConnectBaySet $interConnectBaySet  `
                 -Bays $bayConfig -FabricRedundancy $redundancyType `
                 -enablenetworkLoopProtection $enableNetworkLoopProtection `
                 -enableEnhancedLLDPTLV $enableRichTLV `
                 -lldpAddressingMode $lldpIpAddressMode -enableLLDPTagging $enableTaggedLldp -interconnectConsistencyChecking $interconnectConsistency `
                 -snmp $SnmpConfiguration  


} # if ($lig -eq $Null)
else
{
    write-host -foreground YELLOW 'LIG-Ethernet' already exists.
}


write-host -foreground CYAN "----- Creating logical interconnect group LIG-FC " 
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'LIG-FC' 
if ($lig -eq $Null)
{
    # -------------- Attributes for LIG "LIG-FC"
    $name                                  = "LIG-FC"
    $frameCount                            = 1
    $interconnectBaySet                    = 2
    $fabricModuleType                      = 'SEVCFC'
    $redundancyType                        = "Redundant"
    $bayConfig                             = @{Frame1=@{Bay2='SEVC16GbFC';Bay5='SEVC16GbFC'}}
    $enableNetworkLoopProtection           = $True
    $enableRichTLV                         = $False
    $enableTaggedLldp                      = $False
    $lldpIpAddressMode                     = 'IPV4'
    $interconnectConsistency               = 'Exact'


    $communityString                       = 'public'
    $snmpConfiguration                     = New-OVSnmpConfiguration  -snmpV1 $True -ReadCommunity $communityString  




    $lig = New-OVLogicalInterconnectGroup -Name $name  -fabricModuleType $fabricModuleType -frameCount $frameCount -interConnectBaySet $interConnectBaySet  `
                 -Bays $bayConfig -FabricRedundancy $redundancyType `
                 -enablenetworkLoopProtection $enableNetworkLoopProtection `
                 -enableEnhancedLLDPTLV $enableRichTLV `
                 -lldpAddressingMode $lldpIpAddressMode -enableLLDPTagging $enableTaggedLldp -interconnectConsistencyChecking $interconnectConsistency `
                 -snmp $SnmpConfiguration  


} # if ($lig -eq $Null)
else
{
    write-host -foreground YELLOW 'LIG-FC' already exists.
}


write-host -foreground CYAN "----- Creating logical interconnect group LIG-VC3 " 
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'LIG-VC3' 
if ($lig -eq $Null)
{
    # -------------- Attributes for LIG "LIG-VC3"
    $name                                  = "LIG-VC3"
    $frameCount                            = 3
    $interconnectBaySet                    = 3
    $fabricModuleType                      = 'SEVC40f8'
    $redundancyType                        = "HighlyAvailable"
    $bayConfig                             = @{Frame1=@{Bay3='SEVC40f8';Bay6='SE20ILM'};Frame2=@{Bay3='SE20ILM';Bay6='SEVC40f8'};Frame3=@{Bay3='SE20ILM';Bay6='SE20ILM'}}
    $enableNetworkLoopProtection           = $True
    $enableRichTLV                         = $False
    $enableTaggedLldp                      = $False
    $lldpIpAddressMode                     = 'IPV4'
    $interconnectConsistency               = 'Exact'
    $internalNetworks                      = @("NCS ESX FT 123";"iSCSI VSA";"NHITSTenant11";"NHITSMGMT3";"NHITSTenant52";"NHITSTenant21";"NHITSESXFT1";"NHITSTenant53";"NCS ESX VMOTION 122";"vMotion";"NHITSEXT3";"NHITSESXVMotion1";"NHITSMGMT2";"NHITSTenant31";"VMware Autodeploy";"NHITSMS1";"NHITSESXVMotion2";"NCS ESX VSAN 121";"NHITSEXT1";"NHITSESXFT2";"NHITSTenant41";"NHITSMGMT1";"NHITSTenant43";"NHITSTenant13";"NHITSTenant32";"NHITSESXFT3";"NHITSTenant23";"NHITSTenant33";"NHITSMS3";"NHITSEXT2";"NHITSTenant42";"NHITSTenant51";"NHITSESXVMotion3";"NHITSTenant22";"NHITSTenant12";"NHITSMS2") | % {Get-OVNetwork -name $_}
    $internalNetworkConsistency            = 'Exact'


    $communityString                       = 'public'


    $snmpv3Users                           = [System.Collections.ArrayList]::new()
    $snmpv3Usernames                       = [System.Collections.ArrayList]::new()


    write-host -foreground CYAN "----- Creating snmpV3 user snmp_v3 " 
    $snmpv3User1                           = new-OVSnmpV3User  -UserName "snmp_v3" 


    $snmpv3Users                           = @($snmpv3User1)
    $snmpv3Usernames                       = @('snmp_v3')
    $this_index                            = [array]::IndexOf($snmpV3Usernames, "snmp_v3" )
    $snmpV3user                            = $snmpV3Users[$this_index]
    write-host -foreground CYAN '----- Creating snmp trap $trap1 '
    $trap1                                 = New-OVSnmpTrapDestination  -SnmpFormat SNMPv3  -Destination "192.168.1.67"  -Port 162  -NotificationType "Inform"  -SnmpV3user $snmpV3user 




    $snmpTraps                             = @($trap1)
    $snmpConfiguration                     = New-OVSnmpConfiguration  -snmpV1 $True -ReadCommunity $communityString  -snmpV3 $True -snmpV3Users $snmpV3Users  -TrapDestination $snmpTraps   




    $lig = New-OVLogicalInterconnectGroup -Name $name  -fabricModuleType $fabricModuleType -frameCount $frameCount -interConnectBaySet $interConnectBaySet  `
                 -Bays $bayConfig -FabricRedundancy $redundancyType `
                 -InternalNetworks $internalNetworks -internalNetworkConsistencyChecking $internalNetworkConsistency -enablenetworkLoopProtection $enableNetworkLoopProtection `
                 -enableEnhancedLLDPTLV $enableRichTLV `
                 -lldpAddressingMode $lldpIpAddressMode -enableLLDPTagging $enableTaggedLldp -interconnectConsistencyChecking $interconnectConsistency `
                 -snmp $SnmpConfiguration  


} # if ($lig -eq $Null)
else
{
    write-host -foreground YELLOW 'LIG-VC3' already exists.
}


write-host -foreground CYAN "----- Creating logical interconnect group OBT-LIG-FC2-5 " 
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'OBT-LIG-FC2-5' 
if ($lig -eq $Null)
{
    # -------------- Attributes for LIG "OBT-LIG-FC2-5"
    $name                                  = "OBT-LIG-FC2-5"
    $frameCount                            = 1
    $interconnectBaySet                    = 2
    $fabricModuleType                      = 'SEVCFC'
    $redundancyType                        = "Redundant"
    $bayConfig                             = @{Frame1=@{Bay2='SEVC16GbFC';Bay5='SEVC16GbFC'}}
    $enableNetworkLoopProtection           = $True
    $enableRichTLV                         = $False
    $enableTaggedLldp                      = $False
    $lldpIpAddressMode                     = 'IPV4'
    $interconnectConsistency               = 'Exact'




    $lig = New-OVLogicalInterconnectGroup -Name $name  -fabricModuleType $fabricModuleType -frameCount $frameCount -interConnectBaySet $interConnectBaySet  `
                 -Bays $bayConfig -FabricRedundancy $redundancyType `
                 -enablenetworkLoopProtection $enableNetworkLoopProtection `
                 -enableEnhancedLLDPTLV $enableRichTLV `
                 -lldpAddressingMode $lldpIpAddressMode -enableLLDPTagging $enableTaggedLldp -interconnectConsistencyChecking $interconnectConsistency `
                 


} # if ($lig -eq $Null)
else
{
    write-host -foreground YELLOW 'OBT-LIG-FC2-5' already exists.
}


write-host -foreground CYAN "----- Creating logical interconnect group PYTHON-OBT-LIG-FC2-5 " 
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'PYTHON-OBT-LIG-FC2-5' 
if ($lig -eq $Null)
{
    # -------------- Attributes for LIG "PYTHON-OBT-LIG-FC2-5"
    $name                                  = "PYTHON-OBT-LIG-FC2-5"
    $frameCount                            = 1
    $interconnectBaySet                    = 2
    $fabricModuleType                      = 'SEVCFC'
    $redundancyType                        = "Redundant"
    $bayConfig                             = @{Frame1=@{Bay2='SEVC16GbFC';Bay5='SEVC16GbFC'}}
    $enableNetworkLoopProtection           = $True
    $enableRichTLV                         = $False
    $enableTaggedLldp                      = $False
    $lldpIpAddressMode                     = 'IPV4'
    $interconnectConsistency               = 'Exact'


    $communityString                       = 'public'
    $contact                               = 'dung@hpe.com'


    $snmpv3Users                           = [System.Collections.ArrayList]::new()
    $snmpv3Usernames                       = [System.Collections.ArrayList]::new()


    write-host -foreground CYAN "----- Creating snmpV3 user dung3 " 
    $snmpv3User1                           = new-OVSnmpV3User  -UserName "dung3" 


    write-host -foreground CYAN "----- Creating snmpV3 user dung2 " 
    $snmpv3User2                           = new-OVSnmpV3User  -UserName "dung2" 


    $snmpv3Users                           = @($snmpv3User1,$snmpv3User2)
    $snmpv3Usernames                       = @('dung3','dung2')
    write-host -foreground CYAN '----- Creating snmp trap $trap1 '
    $trap1                                 = New-OVSnmpTrapDestination  -SnmpFormat SNMPv1  -Destination "10.1.1.1"  -Port 162  -Community public 


    $this_index                            = [array]::IndexOf($snmpV3Usernames, "dung2" )
    $snmpV3user                            = $snmpV3Users[$this_index]
    write-host -foreground CYAN '----- Creating snmp trap $trap2 '
    $trap2                                 = New-OVSnmpTrapDestination  -SnmpFormat SNMPv3  -Destination "10.1.1.2"  -Port 164  -NotificationType "Inform"  -SnmpV3user $snmpV3user 


    $this_index                            = [array]::IndexOf($snmpV3Usernames, "dung3" )
    $snmpV3user                            = $snmpV3Users[$this_index]
    write-host -foreground CYAN '----- Creating snmp trap $trap3 '
    $trap3                                 = New-OVSnmpTrapDestination  -SnmpFormat SNMPv3  -Destination "10.1.1.3"  -Port 165  -NotificationType "Trap"  -EngineID "10x123456789A"  -SnmpV3user $snmpV3user 




    $snmpTraps                             = @($trap1,$trap2,$trap3)
    $snmpConfiguration                     = New-OVSnmpConfiguration  -snmpV1 $True -ReadCommunity $communityString  -Contact $contact  -snmpV3 $True -snmpV3Users $snmpV3Users  -TrapDestination $snmpTraps   




    $lig = New-OVLogicalInterconnectGroup -Name $name  -fabricModuleType $fabricModuleType -frameCount $frameCount -interConnectBaySet $interConnectBaySet  `
                 -Bays $bayConfig -FabricRedundancy $redundancyType `
                 -enablenetworkLoopProtection $enableNetworkLoopProtection `
                 -enableEnhancedLLDPTLV $enableRichTLV `
                 -lldpAddressingMode $lldpIpAddressMode -enableLLDPTagging $enableTaggedLldp -interconnectConsistencyChecking $interconnectConsistency `
                 -snmp $SnmpConfiguration  


} # if ($lig -eq $Null)
else
{
    write-host -foreground YELLOW 'PYTHON-OBT-LIG-FC2-5' already exists.
}


write-host -foreground CYAN "----- Creating logical interconnect group vc-fc " 
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'vc-fc' 
if ($lig -eq $Null)
{
    # -------------- Attributes for LIG "vc-fc"
    $name                                  = "vc-fc"
    $frameCount                            = 1
    $interconnectBaySet                    = 2
    $fabricModuleType                      = 'SEVCFC'
    $redundancyType                        = "Redundant"
    $bayConfig                             = @{Frame1=@{Bay2='SEVC16GbFC';Bay5='SEVC16GbFC'}}
    $enableNetworkLoopProtection           = $True
    $enableRichTLV                         = $False
    $enableTaggedLldp                      = $False
    $lldpIpAddressMode                     = 'IPV4'
    $interconnectConsistency               = 'Exact'


    $communityString                       = 'public'
    $snmpConfiguration                     = New-OVSnmpConfiguration  -snmpV1 $True -ReadCommunity $communityString  




    $lig = New-OVLogicalInterconnectGroup -Name $name  -fabricModuleType $fabricModuleType -frameCount $frameCount -interConnectBaySet $interConnectBaySet  `
                 -Bays $bayConfig -FabricRedundancy $redundancyType `
                 -enablenetworkLoopProtection $enableNetworkLoopProtection `
                 -enableEnhancedLLDPTLV $enableRichTLV `
                 -lldpAddressingMode $lldpIpAddressMode -enableLLDPTagging $enableTaggedLldp -interconnectConsistencyChecking $interconnectConsistency `
                 -snmp $SnmpConfiguration  


} # if ($lig -eq $Null)
else
{
    write-host -foreground YELLOW 'vc-fc' already exists.
}


write-host -foreground CYAN "----- Creating logical interconnect group LIG-SAS " 
$lig                                       = get-OVLogicalInterconnectGroup | where name -eq  'LIG-SAS' 
if ($lig -eq $Null)
{
    # -------------- Attributes for LIG "LIG-SAS"
    $name                                  = "LIG-SAS"
    $frameCount                            = 1
    $interconnectBaySet                    = 1
    $fabricModuleType                      = 'SAS'
    $bayConfig                             = @{Frame1=@{Bay1='SE12SAS';Bay4='SE12SAS'}}
    $lig = New-OVLogicalInterconnectGroup -Name $name  -fabricModuleType $fabricModuleType -frameCount $frameCount -interConnectBaySet $interConnectBaySet  -Bays $bayConfig
} # if ($lig -eq $Null)
else
{
    write-host -foreground YELLOW 'LIG-SAS' already exists.
}


Disconnect-OVMgmt
